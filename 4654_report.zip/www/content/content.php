<?php // utf8-marker = äöü
if(!defined('CMSIMPLE_VERSION') || preg_match('/content.php/i', $_SERVER['SCRIPT_NAME']))
{
	die('No direct access');
}
?>
<h1 class="_level1_page_">Welcome - MYE048 Lab Report</h1>
<p><strong>Welcome to the MYE048 Lab Report!</strong></p>
<p>You are provided with a series of questions per lab exercise.&nbsp;</p>
<p>See the site menu. ("1 - Antennas and Propagation", "2 - Fading Processes", ...)</p>
<blockquote>
<p>Answers must be supplied within the designated blue areas only! (Like this one!!)</p>
</blockquote>
<hr>
<p><span style="text-decoration: underline;"><span style="color: #993300;"><strong>THINGS THAT YOU SHOULD NEVER DO!:</strong></span></span></p>
<ul>
<li><span style="color: #993300;">Remove these light blue areas! Enter your answers <strong><u>within them only</u></strong>!</span>
<ul>
<li><span style="font-family: arial, helvetica, sans-serif; background-color: #ffff00;">If you delete one, <strong>EITHER</strong> undo immediately (Ctrl+z), <strong>OR</strong> restore a backup (see below), <strong>OR</strong> start over with a newly downloaded report.</span>
<ul>
<li><span style="background-color: #ffff00;">Do not attempt to fix such errors in any other way (e.g., html edit, scripting, copy-paste, etc.</span>)</li>
</ul>
</li>
</ul>
</li>
<li><span style="color: #993300;">Edit the HTML of this web site in general.&nbsp;</span></li>
<li><span style="color: #993300;">Alter the text of the report (such as the questions).</span></li>
<li><span style="color: #993300;">Add links and URLs.</span></li>
</ul>
<p><em><span style="color: #993300;">Any such action is ignored when you turnin. Moreover, for security purposes (e.g., remote code execution), <span style="text-decoration: underline;">your report will be permanently rejected</span>, regardless of the correctness of your answers, and even if you managed to maintain the correct html structure.</span></em></p>
<hr>
<p><span style="color: #0000ff;"><strong>General info:</strong></span></p>
<ul>
<li><span style="color: #0000ff;">Use the "floppy disk" button on each RichEdit to save your current answers.<img src="userfiles/images/Capture_saveBtn.PNG" alt=""></span>
<ul>
<li style="list-style-type: none;">
<ul>
<li><span style="color: #0000ff;">You can then continue any time. <span style="text-decoration: underline;">Save often</span>!</span></li>
</ul>
</li>
</ul>
</li>
<li><span style="color: #0000ff;">Add images by pressing the picture button and following the wizard steps.&nbsp;<img src="userfiles/images/Capture_picBtn.PNG" alt=""></span></li>
<li><span style="color: #0000ff;">You can keep the whole application inside a folder that you can periodically backup.</span>
<ul>
<li><span style="color: #0000ff;">All modern OSes offer such functionalities. </span></li>
<li><span style="color: #0000ff;"><span style="text-decoration: underline;">This is optional</span>, and your are responsible for doing this yourself, if you so choose.</span></li>
</ul>
</li>
</ul>
<hr>
<p><span style="color: #008000;"><strong>TURNIN</strong></span></p>
<ol>
<li><span style="color: #008000;">When you have completed all your report answers, press the "<span style="font-family: 'courier new', courier, monospace;">EXPORT ALL LABS FOR TURNIN</span>" button found at the top.</span>
<ul>
<li><span style="color: #008000;">You will get a zip file containing all your answers, for <span style="text-decoration: underline;">all</span> labs. Rename it as you like. </span>
<ul>
<li><span style="color: #008000;">E.g., "<span style="font-family: 'courier new', courier, monospace; color: #008000;">your_zip_file.zip</span>".</span></li>
</ul>
</li>
</ul>
</li>
<li><span style="color: #008000;">Ensure that the ZIP file returned is: i) non-empty, and ii) a valid ZIP file (try to open it with a ZIP utility).</span>
<ul>
<li><span style="color: #008000;">If the ZIP is not returned or is problematic (empty, invalid zip), run the "<span style="font-family: 'courier new', courier, monospace;">cleanup_reports.bat</span>" script inside the application folder. Then retry.</span></li>
</ul>
</li>
<li><span style="color: #008000;">turnin the file (only once per semester) via the command:</span>
<ul>
<li><span style="font-family: 'courier new', courier, monospace; color: #008000;">turnin mye048@cliaskos your_zip_file.zip</span></li>
</ul>
</li>
</ol>
<h1 class="_level1_page_ mceNonEditable">1 - Antennas and Propagation</h1>
<div class="mceNonEditable">
<h2>Description</h2>
<p>Vlab #1 is designed to introduce the students to basic principles of antennas, propagation and coverage estimations in a wireless communication environment. The scope is to observe the cell size variation according to basic parameters that are met in a cellular system.</p>
<p>These include:</p>
<ul>
<li>Transmit power of the base station</li>
<li>Antenna heights of base station and mobile user terminal</li>
<li>Antenna pattern of base station and mobile user terminal</li>
<li>Antenna orientation of the base station and mobile user terminal</li>
<li>Propagation medium between the two nodes of the system</li>
</ul>
<p>Vlabs #1 is generic and the user can vary the parameters between any values. It is important to sustain logical parameters in the model when using the empirical propagation models that do not produce accurate results for extreme frequencies, distances and antenna heights.</p>
<h4>1.2 Exercises</h4>
<h5>1.2.1 Set 1</h5>
<p><strong>A.</strong> Draw a measurement line between the transmitter and the receiver. Set the power of the transmitter to 1dBW, the antenna parameters of the transmitter and receiver equal to λ/2 dipole, the orientation to be equal to 0 degrees, the frequency to be 1GHz, the propagation medium to be Free Space, the transmitter height to be 30 meters and the receiver height to be 2 meters, set the distance between the transmitter and the receiver to be 3 Km and take a measurement of the received signal in dBW on a line connecting the two nodes.</p>
<blockquote id="Lab11A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/1_2023-11-04_20-04-42.png" alt="" width="507" height="286"><img src="userfiles/images/1_1_power_dbwatt.png" alt=""></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p><strong>B</strong>. Increase the transmit power for 10dB at the transmitter, take the same measurement again. What can you observe?</p>
<blockquote id="Lab11B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/1_1_2_receiver power in dbwatt.png" alt="" width="737" height="269"></p>
<p>I can observer that the value has a difference of 9 dB compared to the previous value. I see roughly an eightfold increase in power in db values.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p><strong>C</strong>. Change the antenna parameter at the transmitter to be 3λ/2 dipole and perform the measurements. What can you observe?</p>
<blockquote id="Lab11C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/1_1_3_1_with_dipole_1.5_.png" alt="" width="620" height="421"><img src="userfiles/images/1_1_3_2_with_dipole_1.5.png" alt="" width="623" height="402"></p>
<p>I can observe that the 3/2 dipole in the transmitter has worsen the performance by almost 3db in both cases</p>
<div class="lRu31"><span class="HwtZe" lang="en"><span class="jCAhz ChMk0b"><span class="ryNqvb">when we compare them with their counterpart powers, which correspondes to almost halving the power.<br></span></span></span></div>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p><strong>D</strong>. For the initial parameters change the frequency from 1 GHz to 3 GHz. Take a measurement again. What do you observe?</p>
<blockquote id="Lab11D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/1_1_4.png" alt="" width="628" height="470"></p>
<p>I can observe that the value worsen the performance by approximately 9db when compared with the initial values, which corresponds to an eightfold decrease in power.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p><strong>E</strong>. Finally, at the initial system of A set up change the propagation medium from Free Space to Okumura Hata Urban and perform the measurement. What do you observe?</p>
<blockquote id="Lab11E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/1_1_5.png" alt="" width="643" height="414"></p>
<p>I can observe that the value has decreased by almost 21db compared with the initial values, which corresponds to an 128-fold deccrease in power.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p><strong>F.</strong> Write down all the parameters that you have observed that contribute to the signal variation and cell size between a transmitter and a receiver point.</p>
<blockquote id="Lab11F_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>At this point i observed that the parameters that contribute to the signal variation and cell size are :<br><br></p>
<ul>
<li>The transmitter power</li>
<li>The transmitter dipole (although with smaller changes)</li>
<li>The frequency</li>
<li>The medium</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<h5>1.2.2 Set 2</h5>
<p><strong>A.</strong> For the same topology as A (Set 1) perform a measurement at the same line and compare the Free Space loss predictions, The Okumura-Hata Urban predictions and the Plane Earth loss predictions. What do you observe? Justify on the results.</p>
<blockquote id="Lab12A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>For the initial values we have the 3 measurements below:</p>
<ul>
<li>Free space:<br><img src="userfiles/images/1_1_receiver_power_dbwatt.png" alt=""></li>
<li>Okumura-Hata urban:<br><img src="userfiles/images/1_1_5.png" alt="" width="616" height="397"></li>
<li>Plane earth:<br><img src="userfiles/images/2_1.png" alt="" width="638" height="432"></li>
</ul>
<p>I can observe based on the results that the best medium between the 3 is the free space next the plane earth and finally the okumura-hata urban.</p>
<ul>
<li>The <strong>Free Space model</strong> predicts the highest received power, considering an ideal environment without obstructions and because it has <strong>Path Loss Exponent (n):</strong> 2.</li>
<li>The <strong>Okumura-Hata model</strong> predicts the lowest received power due to its consideration of urban obstacles and frequency-dependent effects&nbsp;and base station antenna height and it has <br><strong>Path Loss Exponent (n):</strong> typically, in urban environments, around 2 to 4. But it has the lowest received power because it considers the most variables in our example.</li>
<li>The <strong>Plane Earth model</strong> falls in between, considering the Earth's curvature but neglecting specific environmental factors. <strong>Path Loss Exponent (n):</strong> 4 for Line-of-Sight (LOS), 6 for Non-Line-of-Sight (NLOS)<br>The path loss exponent in the plane earth model varies depending on whether the transmission path is Line-of-Sight or Non-Line-of-Sight. For LOS paths (direct line of sight between transmitter and receiver), the path loss exponent is typically around 4. For NLOS paths (where the signal may be diffracted or reflected), the path loss exponent tends to be higher, around 6, accounting for additional losses due to diffraction and reflection. So here we probably are considering the case of LOS so we get a better result than the <strong>Okumura-Hata model</strong></li>
</ul>
<p>As we can see from the figure below the okumura-hata-urban model varies greatly, depending on the point of selection .</p>
<p><img src="userfiles/images/comparing_okumura-hata_plane-earth_free-space.png" alt="" width="697" height="346"></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>B. A communication system (Tx and Rx) operate in an open space where the propagation between the two ends is best characterized by the freespace loss model. Another system operates in an environment that is best described by the Okumura Hata urban model. Which system do you believe has a greater coverage?</p>
<blockquote id="Lab12B_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>In most cases, the Free Space Loss model predicts a more extensive coverage compared to the Okumura-Hata urban model. This is because the Free Space Loss model assumes an unobstructed environment without considering the obstacles and signal attenuations typical of urban areas.</p>
<p>The Okumura-Hata urban model, being more realistic for urban settings, factors in obstacles and signal attenuation due to buildings and clutter, leading to a prediction of shorter coverage distances compared to the ideal conditions of the Free Space Loss model.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>C. Set the Tx power to be equal to 20dB and the antennas to be λ/2 of both the Tx and Rx nodes. Set their heights equal to 10m. The receiver has a sensitivity level for acceptable communications equal to -110 dBW. Compute the maximum range of the system using the freespace loss model and the Okumura Hata Urban model.</p>
<blockquote id="Lab12C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><span style="font-family: arial, helvetica, sans-serif; font-size: 16px;">Free Space Loss Model:</span></p>
<p><span style="font-family: arial, helvetica, sans-serif; font-size: 16px;"><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL=20log⁡10(d)+20log⁡10(f)+20log⁡10(4π/c)</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">FSPL</span></span><span class="mrel">=</span></span><span class="base"><span class="mord">20</span><span class="mop">lo<span style="margin-right: 0.01389em;">g</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.207em;"><span style="top: -2.4559em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">10</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord mathnormal">d</span><span class="mclose">)</span><span class="mbin">+</span></span><span class="base"><span class="mord">20</span><span class="mop">lo<span style="margin-right: 0.01389em;">g</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.207em;"><span style="top: -2.4559em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">10</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord mathnormal" style="margin-right: 0.10764em;">f</span><span class="mclose">)</span><span class="mbin">+</span></span><span class="base"><span class="mord">20</span><span class="mop">lo<span style="margin-right: 0.01389em;">g</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.207em;"><span style="top: -2.4559em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">10</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord">4</span><span class="mord mathnormal" style="margin-right: 0.03588em;">π</span><span class="mord">/</span><span class="mord mathnormal">c</span><span class="mclose">)</span></span></span></span></span><span class="math math-inline"><span class="katex"><span class="katex-mathml">d=10^((Sensitivity−20log⁡10(f)−20log⁡10(4π/c))/20log⁡10(d))</span></span></span></span></p>
<p><span style="font-family: arial, helvetica, sans-serif; font-size: 16px;">Okumura Hata Urban Model:</span></p>
<p><span class="math math-inline" style="font-family: arial, helvetica, sans-serif; font-size: 16px;"><span class="katex"><span class="katex-mathml">Path&nbsp;Loss=A+B⋅log⁡10(d)−C⋅log⁡10(hb)</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Path&nbsp;Loss</span></span><span class="mrel">=</span></span><span class="base"><span class="mord mathnormal">A</span><span class="mbin">+</span></span><span class="base"><span class="mord mathnormal" style="margin-right: 0.05017em;">B</span><span class="mbin">⋅</span></span><span class="base"><span class="mop">lo<span style="margin-right: 0.01389em;">g</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.207em;"><span style="top: -2.4559em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">10</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord mathnormal">d</span><span class="mclose">)</span><span class="mbin">−</span></span><span class="base"><span class="mord mathnormal" style="margin-right: 0.07153em;">C</span><span class="mbin">⋅</span></span><span class="base"><span class="mop">lo<span style="margin-right: 0.01389em;">g</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.207em;"><span style="top: -2.4559em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">10</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord"><span class="mord mathnormal">h</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.3361em;"><span style="top: -2.55em; margin-left: 0em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mathnormal mtight">b</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mclose">)</span></span></span></span></span></p>
<p>&nbsp;</p>
<p>Even if i dont use the equations to calculate the distance and i use the lab enviroment the results depent on the frequency, so i take the initial frequency to do the calculations.</p>
<p>&nbsp;</p>
<p>For f = 1GHz</p>
<p><strong>Free Space Loss Model:</strong></p>
<p>We can see the distance is around 70000m</p>
<p><img src="userfiles/images/max_range free_space3.png" alt="" width="676" height="320"></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mclose">&nbsp;</span></span></span></span></span></p>
<p><strong>Okumura Hata Urban Model:</strong></p>
<p>The okumura-hata urban model because of its nature will have many areas with power of -110db in different distances due to its consideration of urban obstacles and frequency-dependent effects</p>
<p><img src="userfiles/images/max_range okumura-hata.png" alt="" width="740" height="351"></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>1.2.3 Set 3</h5>
<p><strong>A.</strong> For the same topology of A (Set 1) perform a measurement on a single receiving point placed at D=1 Km away from the transmitter assuming Free Space Loss medium. The service is assumed to occupy B=10 MHz bandwidth and the receiver has a noise figure of N<sub>f</sub>=10dB.</p>
<p>&nbsp;&nbsp;&nbsp;1. Compute the Noise floor of the system.</p>
<blockquote id="Lab13A1_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>To compute the noise floor of the system, we need to consider the receiver's noise figure (N<sub>f</sub> = 10 dB) and the bandwidth (B = 10 MHz).</p>
<p>The formula for the noise floor in dBW is:</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Noise&nbsp;floor&nbsp;(dBW)=−174+10log<sub>⁡10</sub>(B)+Noise&nbsp;Figure&nbsp;(dB)</span></span></span></p>
<p>Where:</p>
<ul>
<li><span class="math math-inline"><span class="katex"><span class="katex-mathml">−174</span></span></span> dBW/Hz is the thermal noise power at room temperature.</li>
<li><span class="math math-inline"><span class="katex"><span class="katex-mathml">B</span></span></span> is the bandwidth in Hz.</li>
</ul>
<p>Plugging in the values:</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Noise floor (dBW)=−174+10log<sub>⁡10</sub>(10×10^6)+10</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Noise&nbsp;floor&nbsp;(dBW)≈−174+70+10=−94&thinsp;dBW</span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;2. Compute the receiver sensitivity</p>
<blockquote id="Lab13A2_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Given:</p>
<ul>
<li>Transmit power = 1 dBW</li>
<li>Frequency <span class="math math-inline"><span class="katex"><span class="katex-mathml">f=1</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal" style="margin-right: 0.10764em;">f</span><span class="mrel">=</span></span><span class="base"><span class="mord">1</span></span></span></span></span> GHz</li>
<li>Distance <span class="math math-inline"><span class="katex"><span class="katex-mathml">d=3000</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal">d</span><span class="mrel">=</span></span><span class="base"><span class="mord">3000</span></span></span></span></span> meters</li>
<li>Receiver height = 2 meters</li>
<li>Transmitter height = 30 meters</li>
</ul>
<p>First, calculate Free Space Path Loss (FSPL):</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL&nbsp;(dB)=20⋅log⁡<sub>10</sub>(d)+20⋅log⁡<sub>10</sub>(f)+20⋅log⁡<sub>10</sub>(4π)−147.55</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL&nbsp;(dB)=20⋅log⁡<sub>10</sub>(3000)+20⋅log⁡<sub>10</sub>(109)+20⋅log⁡<sub>10</sub>(4π)−147.55</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL&nbsp;(dB)=20⋅3+20⋅9+20⋅log⁡<sub>10</sub>(4π)−147.55</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL&nbsp;(dB)=60+180+20⋅log⁡<sub>10</sub>(4π)−147.55</span></span></span></p>
<p>Approximately, <span class="math math-inline"><span class="katex"><span class="katex-mathml">log⁡<sub>10</sub>(4π)</span></span></span> is around 1.1:</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL (dB)≈240+20⋅1.22−147.55</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL (dB)≈240+24.4−147.55</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">FSPL (dB)≈116.85&thinsp;dB</span></span></span></p>
<p>The received signal:</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Received&nbsp;signal&nbsp;(dBW)=Transmit&nbsp;power&nbsp;(dBW)−FSPL&nbsp;(dB)</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Received&nbsp;signal&nbsp;(dBW)=1&thinsp;dBW−116.85&thinsp;dB</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Received&nbsp;signal&nbsp;(dBW)≈−115.85&thinsp;dBW</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true">&nbsp;</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">SNR&nbsp;(dB)</span></span><span class="mrel">=</span></span><span class="base"><span class="mord text"><span class="mord">Received&nbsp;signal&nbsp;power&nbsp;(dBW)</span></span><span class="mbin">−</span></span><span class="base"><span class="mord text"><span class="mord">Noise&nbsp;floor&nbsp;(dBW)</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">SNR&nbsp;(dB)=(−115.85)&thinsp;dBW−(−94)&thinsp;dBW</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">SNR&nbsp;(dB)=−115.85&thinsp;dBW+94&thinsp;dBW</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">SNR&nbsp;(dB)=21.85&thinsp;dB</span></span></span></p>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Receiver&nbsp;Sensitivity&nbsp;(dBW)</span></span><span class="mrel">=</span></span><span class="base"><span class="mord">−</span><span class="mord">115.85</span><span class="mord text"><span class="mord">dBW</span></span><span class="mbin">−</span></span><span class="base"><span class="mord">21.85</span><span class="mord text"><span class="mord">dB</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Receiver&nbsp;Sensitivity&nbsp;(dBW)=−137.7&thinsp;dBW</span></span></span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;3. Compute how many dBs your signal strength is higher that the receiver sensitivity and the noise floor (SNR) at distance D.</p>
<blockquote id="Lab13A3_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>&nbsp;</p>
<ul>
<li><span style="font-size: 16px;">Signal Strength (received) = -115.85 dBW</span></li>
<li><span style="font-size: 16px;">Receiver Sensitivity = -137.7 dBW</span></li>
<li><span style="font-size: 16px;">Noise Floor = -94 dBW</span></li>
</ul>
<p><span style="font-size: 16px; font-family: arial, helvetica, sans-serif;">Signal Strength vs. Receiver Sensitivity:</span></p>
<p><span style="font-size: 16px; font-family: arial, helvetica, sans-serif;" aria-hidden="true">Signal&nbsp;Strength&nbsp;vs.&nbsp;Receiver&nbsp;Sensitivity=−115.85dBW−(−137.7dBW)=21.85dB</span></p>
<p><span style="font-size: 16px; font-family: arial, helvetica, sans-serif;">Signal Strength vs. Noise Floor (SNR):</span></p>
<p><span style="font-size: 16px;"><span aria-hidden="true">Signal Strength vs. Noise Floor=−115.85dBW−(−94dBW)=−21.85dB</span></span></p>
<p>&nbsp;</p>
<ul>
<li>The signal strength is approximately 21.85 dB higher than the receiver sensitivity.</li>
<li>The signal strength is approximately 21.85 dB lower than the noise floor</li>
</ul>
<br>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;4. From the Signal strength value and the Out power of the transmitter, the antenna gains of both the Tx and Rx calculate the path loss assuming the free space loss equation.</p>
<blockquote id="Lab13A4_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">To calculate the antenna gains i use G = ηD,<br></span></span></span></span></span></span></p>
<p>where the antenna's radiation efficiency is η and the directivity is D</p>
<p>I consider Since the antennas specified as being lossless so the radiation efficiency is 1.</p>
<p>From the lab VM i get the directivities of the sender and receiver to be equal to 2.15842 <span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">(dBi)</span></span></span></span></span></span></p>
<p>So G<span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Tx = 2.15842 (dBi)&nbsp; GRx = 2.15842 (dBi)</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Path Loss (dB) </span></span><span class="mrel">= </span></span><span class="base"><span class="mord text"><span class="mord">Transmit&nbsp;power&nbsp;(dBW)</span></span><span class="mbin">−</span></span><span class="base"><span class="mord text"><span class="mord">Signal Strength (received) (dBW)+</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mbin">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; +</span></span><span class="base"><span class="mord text"><span class="mord">Antenna&nbsp;gain&nbsp;Tx&nbsp;(dBi)</span></span><span class="mbin">+</span></span><span class="base"><span class="mord text"><span class="mord">Antenna gain Rx (dBi) </span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Path Loss (dB) = <span class="katex-mathml">1&thinsp;dBW <span class="mbin">−</span><span class="mopen">(</span>−115.85 (dBW<span class="mclose">))</span><span class="mbin">+</span>2.15842 (dBi)<span class="mbin">+</span>2.15842 (dBi)&nbsp;</span><br></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Path Loss (dB) = 121.16684</span></span></span></span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;5. What is the maximum path loss if the system to operate requires the SNR value to be 20dBs?</p>
<blockquote id="Lab13A5_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">New Noise floor (dBW)</span></span><span class="mrel">=</span></span><span class="base"><span class="mord text"><span class="mord">Received&nbsp;signal&nbsp;power&nbsp;(dBW)</span></span><span class="mbin">−</span></span><span class="base"><span class="mord text"><span class="mord">SNR&nbsp;(dB)</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Noise&nbsp;floor&nbsp;(dBW)=−115.85&thinsp;dBW−20&thinsp;dB</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Noise&nbsp;floor&nbsp;(dBW)=−135.85&thinsp;dBW</span></span></span></p>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Maximum&nbsp;Path&nbsp;Loss</span></span><span class="mrel">=</span></span><span class="base"><span class="mord text"><span class="mord">Transmit&nbsp;power</span></span><span class="mbin">−</span></span><span class="base"><span class="mord text"><span class="mord">Noise&nbsp;floor&nbsp;(dBW)</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Maximum&nbsp;Path&nbsp;Loss</span></span><span class="mrel">=</span></span><span class="base"><span class="mord">1</span><span class="mord text"><span class="mord">dBW</span></span><span class="mbin">−</span></span><span class="base"><span class="mopen">(</span><span class="mord">−</span><span class="mord">135.85</span><span class="mord text"><span class="mord">dBW</span></span><span class="mclose">)</span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Maximum&nbsp;Path&nbsp;Loss=136.85&thinsp;dB</span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;6. Assuming that the location variability σ<sub>L</sub>&nbsp;at your Rx point is 8dB calculate the percentage of coverage at the point.</p>
<blockquote id="Lab13A6_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ul>
<li>Received signal power = -115.85 dBW</li>
<li>Receiver Sensitivity = -137.7 dBW</li>
<li>Location variability (σL) = 8 dB</li>
</ul>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">&nbsp;</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Coverage</span></span><span class="mrel">=(</span></span><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.9322em;"><span style="top: -3.4461em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord text mtight">Received signal power</span><span class="mbin mtight">−</span><span class="mord text mtight">Receiver Sensitivity)<span class="vlist-s"><span class="mbin">×</span></span>100/<span style="top: -2.655em;">Location&nbsp;Variability</span></span></span></span></span></span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s"><span class="mord text">Coverage</span><span class="mrel">=(</span><span class="vlist" style="height: 1.01em;"><span style="top: -3.485em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">−115.85<span class="mord text mtight">dBW</span><span class="mbin mtight">−</span><span class="mopen mtight">(</span>−137.7<span class="mord text mtight">dBW</span><span class="mclose mtight">)</span></span></span></span></span>​<span class="mbin">×</span>100)/<span class="vlist" style="height: 1.01em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">8<span class="mord text mtight">dB</span></span></span></span></span></span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s"><span class="katex-mathml">Coverage=(21.85&thinsp;dB/8&thinsp;dB)×100</span></span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s"><span class="katex-mathml">Coverage=2.73125×100</span></span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s"> <span class="katex-mathml">Coverage=273.125% <br></span></span></span></span></span></span></span></span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p>&nbsp;&nbsp;&nbsp;7. Perform the same computations for the Okumura Hata model. What is now the coverage percentage?</p>
<blockquote id="Lab13A7_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images.</span></p>
<p>From the vm i get the Received signal power:</p>
<p>Received signal power = -69.678465 dBW</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Receiver&nbsp;Sensitivity&nbsp;(dBW)</span></span><span class="mrel">=</span></span><span class="base"><span class="mord text"><span class="mord">Received&nbsp;signal&nbsp;power&nbsp;(dBW)</span></span><span class="mbin">−</span></span><span class="base"><span class="mord text"><span class="mord">Noise&nbsp;floor&nbsp;(dB)</span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Receiver&nbsp;Sensitivity&nbsp;(dBW)=−69.678465&thinsp;dBW−10&thinsp;dB</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">Receiver&nbsp;Sensitivity&nbsp;(dBW)=−79.678465&thinsp;dBW</span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord">Coverage<span class="mrel">=(</span><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.01em;"><span style="top: -3.485em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">−69.678465<span class="mord text mtight">dBW</span><span class="mbin mtight">−</span><span class="mopen mtight">(</span>−79.678465<span class="mord text mtight">dBW</span><span class="mclose mtight">)</span></span></span></span></span><span class="vlist-s">​</span></span></span></span><span class="mbin">×</span>100)/<span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.01em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">8<span class="mord text mtight">dB</span></span></span></span></span></span></span></span> </span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord"><span class="katex-mathml">Coverage=10&thinsp;dB/8&thinsp;dB×100</span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord"> <span class="katex-mathml">Coverage=1.25×100</span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord text"><span class="mord"> <span class="katex-mathml">Coverage=125%</span></span></span></span><br></span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
</div>
<h1 class="_level1_page_ mceNonEditable">2 - Fading Processes</h1>
<div class="mceNonEditable">
<h1>2 Virtual Labs #2: Fading Processes</h1>
<h5>2.1 Description</h5>
<p>Vlabs #2 is designed to introduce the student to basic fading processes and narrow band and wideband channel characteristics.</p>
<p>The Vlab #2 comprises of a simple scenario where a base station transmits signals and the receiver is moving on a straight line on a street in between building blocks. The scenario assumes simplified propagation mechanisms based on empirical models and simple shadowing parameters. The scope is to observe channel predictions over the scenario and understand the concept of Rice and Rayleigh fading, Power delay profiles and time variant channel behavior.</p>
<p>The channel model used is the Jakes model as presented in M. Patzold, et. al., ‘Modeling, analysis and simulation for non frequency selective mobile radio channels with asymmetrical Doppler power spectral density shapes’, IEEE Transaction Vehicular Technology, vol. 46, no.2, 1997 the book S. Saunders, A. Zavala, ‘Antennas and Propagation for Wireless Communication Systems’, WILEY, ISBN 978-0-470-84879-1, 2007.</p>
<p>The Vlab has an interface that enables the user to adjust parameters like:</p>
<p>1. Set Geometry Data -Antenna Height, Type, Elevation, Azimuth, Horizon and distance from the road -Buildings, percentage of LOS between building blocks and Tx, distance between buildings of the street.</p>
<p>2. Set Transmitter</p>
<ul>
<li>a) Medium Received Data</li>
<li>b) Power out of Tx</li>
<li>c) Frequency</li>
<li>d) Propagation medium</li>
<li>e) Receiver speed</li>
<li>f) Receiver antenna type</li>
</ul>
<p>3. Set Channel data</p>
<ul>
<li>a) Rice factor</li>
<li>b) Number of secondary paths</li>
<li>c) White noise</li>
<li>d) Modulation</li>
</ul>
<p>4. Simulation</p>
<ul>
<li>a) Path loss, shadowing and antenna gains parameters</li>
<li>b) Delay profile</li>
<li>c) Received field with time assuming constant speed of vehicle.</li>
<li>d) Real Time channel analysis.</li>
</ul>
<h4>2.2 Exercises</h4>
<h4>2.2.1 Set 1</h4>
<p><strong>A.</strong> Set the frequency at Block 2 of the GUI to 1 GHz and the speed of the vehicle at 80 Km/h. At Block 3 of the GUI set the Rice factor to be equal to 1. Then click on the view button next to the Rice factor parameter. Now set the Rice factor to be equal to 6 and click again. What do you observe?</p>
<blockquote id="Lab21A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1.png" alt=""></p>
<p><img src="userfiles/images/lab2_1_1_1.png" alt=""></p>
<ul>
<li>LOS Rice factor 1: This indicates significant signal fading. I observe more variability in signal strength and quality, potentially experiencing frequent dropouts or interruptions in communication due to fading effects.</li>
<li>
<p>LOS Rice factor 6: This indicates lower fading. I observe a more stable and consistent signal strength and quality, with fewer fluctuations or disruptions in the communication or signal reception.</p>
</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Why is the channel variation smaller for higher Rice Factor? Write down the equation of the Rice factor and justify.</p>
<blockquote id="Lab21B_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>A higher Rice factor typically indicates that the signal is stronger compared to the scattered components of the signal, resulting in less severe signal fading or variation. This means that the signal experiences less distortion due to the environment.</p>
<p>So, for a higher Rice factor, i have better signal propagation, leading to lower channel variation. Lower variation means the transmitted signal is more consistent and less affected by the fluctuations in the communication channel.</p>
<p>Rician Factor equation:</p>
<p><span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> K = ν 2 2 σ 2 </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -2.171ex; width: 9.548ex; height: 6.009ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/4622353a732a2cbe6ed2b4fc32fbf45f45b17600" alt="{\displaystyle K={\frac {\nu ^{2}}{2\sigma ^{2}}}}" aria-hidden="true"></span></p>
<p>is the ratio between the power in the direct path and the power in the other scattered paths.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now set the Frequency equal to 5 GHz maintaining the speed of the vehicle at 80Km/h and Rice factor 6. Click again on the view button. What do you observe? Explain why the channel variations are more frequent for higher frequency. Use the concept of multipaths and their relative phases to explain.</p>
<blockquote id="Lab21C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_3.png" alt=""></p>
<p>I can observe more frequent channel variations.</p>
<p>Multipath propagation occurs when transmitted signals take multiple paths to reach the receiver. These paths can involve reflections, diffractions, and scattering off objects in the environment. At higher frequencies, shorter wavelengths allow signals to interact more with obstacles, buildings, and other objects in their path.</p>
<p>When signals encounter these obstacles, they reflect and refract in various directions, creating multiple signal paths with different lengths. The difference in path lengths leads to phase differences among the signals arriving at the receiver. These signals can interfere constructively or destructively, causing variations in signal strength known as fading.</p>
<p>At higher frequencies, the wavelengths are shorter, making the signal more susceptible to changes in the environment. Even small changes in the surroundings or slight movements of the transmitting or receiving devices can result in significant phase differences among the multipath signals. As a result, the constructive and destructive interference patterns change more frequently, leading to more rapid and noticeable channel variations.</p>
<p>In essence, higher frequencies lead to shorter wavelengths, increased interaction with obstacles, and more rapid changes in phase relationships among multipath signals, causing more frequent and pronounced channel variations in wireless communications.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> For the frequency of 1GHz change the vehicle speed from 80Km/h to 5 Km/h which represents the pedestrian speed. What do you observe?</p>
<blockquote id="Lab21D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_4.png" alt=""></p>
I can observe a more stable and consistent signal strength and quality, with fewer fluctuations and low channel variation.<br>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Write down the maximum variation observed on the signal for Rice factor equal to 0 and Rice factor equal to 6 for the frequency of 1GHz. Justify the difference. Compare the probability density functions for the two Rice factors and justify the difference.</p>
<blockquote id="Lab21E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Rice factor 6:</p>
<p>The highest value observed by the ydata of the above graph is 16.57075864 db</p>
<p>The lowest value observed by the ydata of the above graph is 13.70918877 db</p>
<p>Rice factor 0:</p>
<p>The highest value observed by the ydata of the above graph is 6.2536412913226 db</p>
<p>The lowest value observed by the ydata of the above graph is -19.85227828370388 db</p>
<p>&nbsp;</p>
<p>The <a title="Probability density function" href="https://en.wikipedia.org/wiki/Probability_density_function">probability density function</a> is</p>
<dl>
<dd><span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> f ( x ∣ ν , σ ) = x σ 2 exp ⁡ ( − ( x 2 + ν 2 ) 2 σ 2 ) I 0 ( x ν σ 2 ) , </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -3.171ex; width: 46.198ex; height: 7.509ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/251cb9a83dfc0318b726d5d9fd89d38d69b33946" alt="f(x\mid \nu ,\sigma )={\frac  {x}{\sigma ^{2}}}\exp \left({\frac  {-(x^{2}+\nu ^{2})}{2\sigma ^{2}}}\right)I_{0}\left({\frac  {x\nu }{\sigma ^{2}}}\right)," aria-hidden="true"></span></dd>
</dl>
<h3>For <span class="math math-inline"><span class="katex"><span class="katex-mathml">K=0</span> </span></span>:</h3>
<p><span class="math math-inline" style="font-size: 20px;"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal" style="margin-right: 0.10764em;">f</span><span class="mopen">(</span><span class="mord mathnormal">x</span><span class="mpunct">;</span><span class="mord">ν</span><span class="mpunct">,</span><span class="mord mathnormal" style="margin-right: 0.03588em;">σ</span><span class="mclose">)</span><span class="mrel">=(x/</span></span><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.6954em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​)</span></span></span></span></span><span class="mop">exp</span><span class="minner"><span class="mopen delimcenter" style="top: 0em;"><span class="delimsizing size2">(</span></span><span class="mord">−</span><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.0179em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">2<span style="top: -3.394em;"><span class="mord mathnormal mtight">x</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.8913em;"><span style="top: -2.931em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span>/<span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mclose delimcenter" style="top: 0em;"><span class="delimsizing size2">)<span class="mord"><span class="mord mathnormal" style="margin-right: 0.07847em;">I</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><sub><span class="vlist" style="height: 0.3011em;"><span style="top: -2.55em; margin-left: -0.0785em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">0</span></span></span></span></sub><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(</span><span class="mord">0</span><span class="mclose">)</span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline" style="font-size: 20px;"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal" style="margin-right: 0.10764em;">f</span><span class="mopen">(</span><span class="mord mathnormal">x</span><span class="mpunct">;</span><span class="mord">ν</span><span class="mpunct">,</span><span class="mord mathnormal" style="margin-right: 0.03588em;">σ</span><span class="mclose">)</span><span class="mrel">=(x/</span></span><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.6954em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​)</span></span></span></span></span><span class="mop">exp</span><span class="minner"><span class="mopen delimcenter" style="top: 0em;"><span class="delimsizing size2">(</span></span><span class="mord">−</span><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.0179em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">2<span style="top: -3.394em;"><span class="mord mathnormal mtight">x</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.8913em;"><span style="top: -2.931em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span>/<span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mclose delimcenter" style="top: 0em;"><span class="delimsizing size2">)</span></span></span></span></span></span></span></p>
<p>The exponential term <span class="math math-inline" style="font-size: 20px;"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mop">exp</span><span class="minner"><span class="mopen delimcenter" style="top: 0em;"><span class="delimsizing size2">(</span></span><span class="mord">−</span><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.0179em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">2<span style="top: -3.394em;"><span class="mord mathnormal mtight">x</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.8913em;"><span style="top: -2.931em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span>/<span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mclose delimcenter" style="top: 0em;"><span class="delimsizing size2">) </span></span></span></span></span></span></span>indicates the distribution's tail-off, showing the probability of receiving different signal strengths. Also Bessel function equals to 1</p>
<h3>For <span class="math math-inline"><span class="katex"><span class="katex-mathml">K=6</span> </span></span>:</h3>
<p><span class="math math-inline" style="font-size: 20px;"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal" style="margin-right: 0.10764em;">f<span class="mopen">(</span><span class="mord mathnormal">x</span><span class="mpunct">;</span><span class="mord">ν</span><span class="mpunct">,</span><span class="mord mathnormal" style="margin-right: 0.03588em;">σ</span><span class="mclose">)</span><span class="mrel">=(x/</span><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.6954em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​)</span></span></span></span></span><span class="mop">exp</span><span class="minner"><span class="mopen delimcenter" style="top: 0em;"><span class="delimsizing size2">((</span></span><span class="mord">−</span><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 1.0179em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">2<span style="top: -3.394em;"><span class="mord mathnormal mtight">x</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.8913em;"><span style="top: -2.931em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span>/<span class="mord mathnormal mtight" style="margin-right: 0.03588em;">σ</span><sup><span class="msupsub"><span class="vlist-t"><span class="vlist" style="height: 0.7463em;"><span style="top: -2.786em; margin-right: 0.0714em;"><span class="sizing reset-size3 size1 mtight">2</span></span></span></span></span></sup></span></span></span></span><span class="vlist-s">​)-6</span></span></span></span></span><span class="mclose delimcenter" style="top: 0em;"><span class="delimsizing size2">)<span class="math math-inline"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.07847em;">I</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><sub><span class="vlist" style="height: 0.3011em;"><span style="top: -2.55em; margin-left: -0.0785em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">0</span></span></span></span></sub><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(x*sqrt</span>(12)/σ<span class="mclose">)</span></span></span></span></span></span></span></span></span></span></p>
<ul>
<li>The additional term <span class="math math-inline"><span class="katex"><span class="katex-mathml">exp⁡(−6)</span></span></span> in the exponential function suppresses the distribution, leading to a narrower spread of received signal strengths.</li>
<li>The presence of the modified Bessel function&nbsp;<span class="math math-inline" style="font-size: 16px;"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord mathnormal" style="margin-right: 0.10764em;"><span class="minner"><span class="mclose delimcenter" style="top: 0em;"><span class="delimsizing size2"><span class="math math-inline"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.07847em;">I</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><sub><span class="vlist" style="height: 0.3011em;"><span style="top: -2.55em; margin-left: -0.0785em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight">0</span></span></span></span></sub><span class="vlist-s">​</span></span></span></span></span><span class="mopen">(x*sqrt</span>(12)/σ<span class="mclose">) </span></span></span></span></span></span></span></span></span></span>further shapes the distribution, contributing to the concentration of received signal strengths around a specific range.</li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> At Block 3 of GUI set the secondary paths equal to 1, RMS Delay environment Urban Macrocell and press the view button. The observation is a secondary path variation with time similar to the variations observed for the rice factor equal to 0. This is because the secondary paths suffer NLOS conditions and mainly have a Rice factor close to 0. Now set the secondary paths equal to 10. Press the view button. What do you observe?</p>
<blockquote id="Lab21F_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_5.png" alt="" width="737" height="326"></p>
<p>This takes even more time because we have also characteristics of multipath propagation and NLOS conditions this is because by increasing the number of secondary paths to 10 i amplify the effect of multipath propagation.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>G.</strong> Change the RMS delay environment to Indoor and then to Open. What do you observe?</p>
<blockquote id="Lab21G_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_7.png" alt="" width="706" height="315"></p>
<p>I observe much smaller times this is because in open areas there are is not much of an effect of multipaths and in indoors</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>H.</strong> For the frequency of 2GHz set the number of multipaths equal to the maximum one and the RMS delay environment to be Urban Macrocell, Hilly Macrocell and Indoor. For the three cases observe the maximum delays between the multipaths and discuss on the impact to the wideband nature of the channel. Why is the delay between the multipaths smaller for indoor environments? When do you expect the channel to be wideband?</p>
<blockquote id="Lab21H_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_6.png" alt="" width="730" height="256"></p>
<p>The greatest dealy is in the hilly enviroment, next in the urban, and lastly in indoors. In an Indoor environment, the maximum delays between multipaths tend to be smaller. This is due to shorter propagation distances, fewer obstacles, and less scattering compared to outdoor environments. An indoor setting results in a reduction of delay spread.</p>
<p>&nbsp;</p>
<p>A a system is wideband when the message bandwidth significantly exceeds the coherance bandwidth of the channel and with smaller delay spreads, such as in indoor environments with reduced delay between multipaths, the channel tends to be more suitable for wideband transmission.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>I.</strong> Set the Rice factor equal to 1, the frequency equal to 1GHz, speed equal to 80Km/h and the Eb/No value equal to the maximum one. Click the view button. What do you observe? Now set the value of Eb/No equal to 20 dB and click on the view button. What do you observe?</p>
<blockquote id="Lab21I_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_8.png" alt="" width="691" height="300"></p>
<p>&nbsp;</p>
<p>Eb/No = 30 db</p>
<ul>
<li>When setting Eb/No to its maximum value, the system exhibits optimal performance. The received signal quality should be high, with minimal errors or distortions.</li>
<li>&nbsp;A higher Eb/No signifies a more favorable ratio of signal power to noise power, indicating better signal strength relative to the background noise. This results in a higher quality received signal with fewer errors or distortions.</li>
</ul>
<p>Eb/No = 20 db</p>
<ul>
<li>Lowering the Eb/No to 20 dB from 30 dB&nbsp; leads to a slight reduction in signal quality, but the difference might not be substantial.</li>
<li>Although a 20 dB Eb/No still represents a high signal-to-noise ratio, it's marginally lower compared to 30 dB. The system might still maintain very good signal quality, but there is a slight increase in error rates compared to the 30 dB scenario.</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>J.</strong> Now set the Eb/No value equal to 0dB. Click on the view button again. What do you observe?</p>
<blockquote id="Lab21J_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_9.png" alt="" width="459" height="402"></p>
<p>&nbsp;</p>
<p>Eb/No = 0 db</p>
<p>A 0 dB Eb/No signifies that the signal power is at the same level as the noise power. This balance leads to a significant increase in error rates, causing more noticeable degradation in signal quality compared to higher Eb/No values.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>K.</strong> Finally set the Eb/No value equal to -10dB. Click on the view button again. What do you observe?</p>
<blockquote id="Lab21K_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_10.png" alt="" width="506" height="448"></p>
<p>&nbsp;</p>
<p>Eb/No = -10 db</p>
<p>Decreasing the Eb/No to -10 dB indicates a significantly lower signal-to-noise ratio, leading to poorer signal quality.</p>
<p>At -10 dB, the noise power surpasses the signal power, resulting in a situation where the noise is stronger than the signal. This scenario leads to a considerable increase in errors and a substantial degradation in signal quality.</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h4>2.2.2 Set 2</h4>
<p><strong>A.</strong> At Block 1 of the GUI set the antenna height at 20m, elevation, azimuth and horizon 0<sup>o</sup>, distance from the road at 500m. The LOS parameter set equal to 20% and the distance of buildings equal to 10m. Set the T<sub>x</sub> power equal to 10dBW and the frequency at 2GHz. The antenna type of the T<sub>x</sub> to be λ/2 dipole. Set the medium freespace and the mobile speed at 80Km/h with antenna type λ/2 dipole. At Block 3 of GUI set the RMS environment to be Urban Macrocell. The number of secondary paths to be equal to 1. The Rice factor to be 1 and the Eb/No=15dB. Run the simulation at block 4 of the GUI by clicking only the Pathloss, Shadowing button. What do you observe?</p>
<blockquote id="Lab22A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_11.png" alt=""></p>
<p>I can observe that the highest path loss is at 90 - 110 meters which corresponds with the lowest trasmitter and receiver antenna gains at 90 - 110 meters which is the are where the antennas cannot concentrate the radiated energy in that specific direction.</p>
<p>I can observe the highest Shadowing losses and Aggregate gains at 18 - 38 meters , 73 - 91 meters and 126 - 147 meters which is where there are gaps in the building so we have large-scale variations in the propagation environment, caused by obstacles, buildings and this results in Aggregate gains which represent the cumulative effect of various factors that enhance the received signal strength which include antenna gains, multipath gains and others. So i have stronger gains closer to (-90 dB) and lower gains at (-130 dB). About Shadowing losses i have lower losses at 0 db with relatively better propagation conditions when there are no buildings, while higher losses -40 db where there are buildings with more significant signal attenuation.</p>
<p>Minimum BER (Bit Error Rate)<strong>:</strong> 4.4409e-16</p>
<p>Indicates an extremely low bit error rate, showcasing the system's ability to transmit data with high accuracy and reliability.</p>
<p>Minimum SER (Symbol Error Rate)<strong>:</strong> 4.4409e-16</p>
<p>Also reflects an exceptionally low symbol error rate, indicating accurate symbol reception and minimal errors in symbol decoding.</p>
<p>Average Fade Duration: 3</p>
<p>Represents the average duration of fades in the received signal. A value of 3 suggests that, on average, the fading duration lasts for a good period.</p>
<p>Level Crossing Frequency: 4</p>
<p>Indicates the frequency at which the received signal crosses a certain fading threshold. A higher level crossing frequency suggests more frequent variations in the received signal strength.</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Using the graphs presented at the simulated figure and the time channel variations due to multipaths observed in Exercise 1 of Vlabs 2, explain which are the processes that affect the channel variation in the environment.</p>
<blockquote id="Lab22B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><strong>Rice Factor</strong></p>
<p><strong>Frequency</strong></p>
<p><strong>Speed of the Vehicle</strong></p>
<p><strong>Environment</strong></p>
<p><strong>Path Loss</strong></p>
<p><strong>Antenna Characteristics (Gains, Orientation)</strong></p>
<p><strong>Shad</strong><strong>owing and Obstacles</strong></p>
<p><strong>Aggregate Gains and Shadowing Losses</strong></p>
<p><strong>Eb/No (Energy per bit to Noise power Spectral density ratio)</strong></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now set the Rice factor to be equal to 10. In this way you set that at LOS region the Rice factor is 10 and at the NLOS region the Rice factor is automatically set to 0 due to building obstructions. Run again and comment on the observed channel variations.</p>
<blockquote id="Lab22C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_12.png" alt=""></p>
<p>i get almost the same results this is probably because the terrain and buildings stay the same as i did not change the LOS percentage.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Use the slider to move on the signal variations and observe the distribution of the received field. Comment on the results. Where do you expect that the distribution is better characterized by Rayleigh and where by Rice?</p>
<blockquote id="Lab22D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>The biggest changes happen when i change the geometry data and i have distributions best characterized by:</p>
<ul>
<li>
<p><strong>Rayleigh-Like Distribution:</strong></p>
<ul>
<li>Scenarios with weaker or absent LOS signals, more pronounced multipath effects, and a stronger presence of scattered signals exhibit Rayleigh-like distributions.</li>
<li>Rayleigh distributions in enviromets heavily affected by scattering or where the LOS signal is relatively weak compared to the scattered components.</li>
</ul>
</li>
<li>
<p><strong>Rice-Like Distribution:</strong></p>
<ul>
<li>Locations with a strong LOS signal alongside scattered components, with a pronounced dominance of the direct path, showcase distributions resembling the Rice distribution.</li>
<li>Rice distributions in areas where a robust LOS signal exists alongside scattered signals, indicating a stronger direct path compared to scattered components.</li>
</ul>
</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Now change the elevation of the Tx antenna to 60<sup>o</sup> the azimuth to -37<sup>o</sup>, the horizon to 80m and set antenna type of large loop at the T<sub>x</sub> and 3λ/2 at the R<sub>x</sub>. Change the propagation medium to Okumura Hata Urban. Run again and comment.</p>
<blockquote id="Lab22E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_13.png" alt=""></p>
<p>I see the same Shadowing Losses</p>
<p>Transmitter Gains: A stable transmission strength overall, with exceptions at 81m and 155m, where we have potential areas of signal degradation.</p>
<p>Receiver Antenna Gains: Minor variations in reception capability, showcasing subtle changes in the receiver's ability to capture signals across distances.</p>
<p>Path Loss: Shows a gradual decrease in signal strength from 0m to 180m, though the variation between peak and low values is relatively small.</p>
<p><span style="font-size: 16px; font-family: arial, helvetica, sans-serif;">Aggregate Gains:</span></p>
<p>The peak regions indicate relatively stronger signal reception or more favorable conditions within specific distance intervals, particularly at 20-35m, 75-90m, and 130-145m.</p>
<p>The significantly lower aggregate gain at 155m suggests weaker signal reception or less favorable conditions at this specific distance.</p>
<p>The stability in aggregate gains across the rest of the observed distances suggests a consistent level of signal reception or similar conditions beyond the specified peak and low regions.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> Which factors mainly affect the coverage of the cell? Explain and justify your answer with graphs and results.</p>
<blockquote id="Lab22F_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><strong>Transmit Power:</strong></p>
<ul>
<li><strong>Impact:</strong> Higher transmit power increases the signal's reach and coverage area.</li>
</ul>
<p><strong>Environment and Antenna Characteristics:</strong></p>
<ul>
<li><strong>Impact: </strong>Distance, percentage of LOS, antenna distance from road, antenna gain, directionality, and orientation affect signal coverage.</li>
</ul>
<p><strong>Propagation Model :</strong></p>
<ul>
<li><strong>Impact:</strong> Different propagation models (Free Space, Okumura Hata urban) influence signal propagation.</li>
</ul>
<p><strong>Frequency, antenna type, speed :</strong></p>
<ul>
<li><strong>Impact: </strong>Directionality: Omnidirectional vs. directional antennas affect coverage pattern and range.</li>
</ul>
<p>Higher Frequencies: Shorter wavelength, shorter range, and higher susceptibility to attenuation.</p>
<p>Lower Frequencies: Longer wavelength, better penetration, and greater coverage range.</p>
<p><strong>Channel data, noise and loss factor :</strong></p>
<ul>
<li><strong>Impact: </strong></li>
</ul>
<p>Noise:Higher noise levels reduce the signal-to-noise ratio (SNR), degrading coverage and communication reliability.</p>
<p>Loss Factor:Greater path loss, multipath effects, fading and shadowing limit coverage range and can cause signal dead zones in specific areas.</p>
<p>&nbsp;</p>
<p>Graphs and results are presented in the whole exercise above justifing that these factor change the coverage.</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<h4>2.2.3 Set 3</h4>
<p>Set the Rice factor to 10 the frequency 1000MHz, the speed at 80Km/h, the RMS environment Urban Macrocell the antenna at 20m height and 0 orientation of all values, the antenna type of both Tx and Rx to λ/2, the antenna power to 40dBmW, the distance from the car to 500m, the propagation medium equal to Free Space, the secondary path to 1, the Eb/No=15dB and click on the Received Field (t) button at Block 4. Run the simulation. (Remember that if you set the number of secondary paths greater than 1 then the Rice factor will not be assumed equal to the value that you set on the GUI. This is because the simulator considers multipath in all the area including LOS). At the lower part of the presented figure observe the average fade duration and the level crossing rate.</p>
<p><strong>A.</strong> For sensitivity slider equal to -132 dBW write down the average fade duration and the level crossing rate.</p>
<blockquote id="Lab23A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_14.png" alt="" width="754" height="277"></p>
<p>Average Fade duration = 0.002</p>
<p>i consider that the LCF (level crossing frequency) is same as the level crossing rate.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Adjust the frequency to 400MHz, run again and write down the average fade duration and the level crossing rate.</p>
<blockquote id="Lab23B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_15.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now for the frequency of 400MHz change the speed of the vehicle equal to 160 Km/h and write down the average fade duration and the level crossing rate.</p>
<blockquote id="Lab23C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_16.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Set the frequency to 1000MHz and change the speed of the vehicle equal to 30 Km/h and write down the average fade duration and the level crossing rate.</p>
<blockquote id="Lab23D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_17.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Set the LOS parameter equal to 100%. This means that there are no buildings obstructing the signals from the T<sub>x</sub>. Set the propagation medium equal to Okumura Hata Urban. We choose LOS equal to 100% since we use the Okumura Hata model which incorporates through empirical estimations the shadowing losses of the buildings. Set the frequency to 1000MHz and the speed at 80Km/h. The LOS Rice factor equal to 5. Run the simulation and write down the values of the average fade duration and level crossing rates.</p>
<blockquote id="Lab23E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab2_1_1_18.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> Which factors do you expect to influence the average fade duration and the level crossing rate of the system?</p>
<blockquote id="Lab23F_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>From the equations</p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.838ex; width: 20.079ex; height: 3.509ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/a6136b464d61414d2217a322d522af0e90ef0239" alt="{\mathrm  {LCR}}={\sqrt  {2\pi }}f_{d}\rho e^{{-\rho ^{2}}}" aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -2.838ex; width: 17.481ex; height: 7.009ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/b2927123f3806ca6078bccdfd3b36cf572f660cd" alt="{\displaystyle \mathrm {AFD} ={\frac {e^{\rho ^{2}}-1}{\rho f_{d}{\sqrt {2\pi }}}}.}" aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.505ex; width: 24.742ex; height: 3.176ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/5a449078af143c76f779980e8218363817f018ae" alt="{\mathrm  {AFD}}\times {\mathrm  {LCR}}=1-e^{{-\rho ^{2}}}." aria-hidden="true"></span></p>
<p>i expect the average fade duration and level crossing rate to be influenced by <span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> f d </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.671ex; width: 2.231ex; height: 2.509ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/20ee02c09722b2edd84bebb217b4b1cca8bd2d38" alt="f_{d}" aria-hidden="true"></span> is the maximum Doppler shift and <span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> ρ </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.838ex; width: 1.202ex; height: 2.176ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/cb63739ad1b6fd5de470ebeb75e89fc330764d05" alt="\,\!\rho " aria-hidden="true"></span> is the threshold level&nbsp;</p>
<p>by the experimentation i see that they are influenced by speed, frequency, LOS percentage and propagation medium.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>G.</strong> How would you expect that the average fade duration and the level crossing rate will degrade the performance of the system?</p>
<blockquote id="Lab23G_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>The AFD determines the average length of error bursts in fading channels. Hence, in fading channels with relatively large AFD, long data blocks are more likely to be significantly affected by the channel fades than short blocks.</p>
<p>The LCR level crossing rate is a measure of the rapidity of the fading. It quantifies how often the fading crosses some threshold, usually in the positive-going direction. Hence, we will have ntense and frequent fading events and multipath effects also systems experiencing higher LCR might face challenges in maintaining a consistent and stable signal quality nad reduced signal reliability</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>H.</strong> Change the Modulation from PSK-2 to 64 QAM without changing the Eb/No value (=15dB). Run and compare the minimum BER and SER for the two modulation index (PSK=2, 64 QAM).</p>
<blockquote id="Lab23H_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>I get the same results for PSK=2 and QAM 64</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>I.</strong> For a mobile system operating at 1800 MHz (GPRS) and a speed of 90 km/h, how many times would you expect the signal to drop more than 20 dB below its RMS value in 1 minute? How many times for 35 dB fades? How would these values change if the carrier frequency were increased to 2400 MHz (UMTS) and the speed reduced to 60 km/h. (Tip: find the level crossing rate and average fade duration formulas in the book or from online sources).</p>
<blockquote id="Lab23I_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.838ex; width: 20.079ex; height: 3.509ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/a6136b464d61414d2217a322d522af0e90ef0239" alt="{\mathrm  {LCR}}={\sqrt  {2\pi }}f_{d}\rho e^{{-\rho ^{2}}}" aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -2.838ex; width: 17.481ex; height: 7.009ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/b2927123f3806ca6078bccdfd3b36cf572f660cd" alt="{\displaystyle \mathrm {AFD} ={\frac {e^{\rho ^{2}}-1}{\rho f_{d}{\sqrt {2\pi }}}}.}" aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.505ex; width: 24.742ex; height: 3.176ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/5a449078af143c76f779980e8218363817f018ae" alt="{\mathrm  {AFD}}\times {\mathrm  {LCR}}=1-e^{{-\rho ^{2}}}." aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -2.338ex; width: 14.463ex; height: 5.676ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/a9442610afe1f23b016183696dd123faf8f492ef" alt="{\displaystyle \rho ={\frac {R_{\mathrm {threshold} }}{R_{\mathrm {rms} }}}.}" aria-hidden="true"></span></p>
<p><span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> f d </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.671ex; width: 2.231ex; height: 2.509ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/20ee02c09722b2edd84bebb217b4b1cca8bd2d38" alt="f_{d}" aria-hidden="true"></span> is the maximum Doppler shift and <span class="mwe-math-element"><span class="mwe-math-mathml-inline mwe-math-mathml-a11y" style="display: none;"> ρ </span><img class="mwe-math-fallback-image-inline mw-invert" style="vertical-align: -0.838ex; width: 1.202ex; height: 2.176ex;" src="https://wikimedia.org/api/rest_v1/media/math/render/svg/cb63739ad1b6fd5de470ebeb75e89fc330764d05" alt="\,\!\rho " aria-hidden="true"></span> is the threshold level&nbsp;</p>
<p>FOR 1800MHz and 90km/s = 25m/s:</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord">20</span><span class="mord text"><span class="mord"> dB below Rms,&nbsp; RMS calculate via lab = -85db <br></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.00773em;">R</span><sub><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.3361em;"><span style="top: -2.55em; margin-left: -0.0077em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord text mtight">threshold</span></span></span></span></span><span class="vlist-s">​</span></span></span></span></sub></span><span class="mrel">= -110db<br></span></span></span></span></span></p>
<p>ρ = -110/-85= 1,294117647</p>
<p>f<sub>d</sub>= 1800*10^6*(90×1000÷3600)/(3*10^8)=150 hz</p>
<p>LRC = sqrt(2π)150*1,294*e<sup>-1,67</sup></p>
<p>LRC = 486,5*0,188 =&nbsp;91,462</p>
<p>AFD = (1 - e<sup>-1,67</sup>)/91,462 = 0,008875303</p>
<p>For -35db</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.00773em;">R</span><sub><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.3361em;"><span style="top: -2.55em; margin-left: -0.0077em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord text mtight">threshold</span></span></span></span></span><span class="vlist-s">​</span></span></span></span></sub></span><span class="mrel">= -120db</span></span></span></span></span></p>
<p>ρ = -120/-85 = 1,411764706</p>
<p>LRC = sqrt(2π)150*1,41*e<sup>-1,989</sup> = 72,541842382</p>
<p>AFD = (1 - e<sup>-1,989</sup>)/72,5 = 0,011905763</p>
<p>&nbsp;</p>
<p>FOR speed 16.6667m/s and 2400MHz</p>
<p>f<sub>d</sub>=2400*10^6*(1.67)/(3*10^8)=13,36Hz</p>
<p>the dopler frequency falls so the LRC falls and the AFD increases</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
</div>
<h1 class="_level1_page_ mceNonEditable">3 - Drive Tests</h1>
<div class="mceNonEditable">
<h3>Virtual Lab #3: Drive Tests</h3>
<h4>3.1 Description</h4>
<p>Vlab #3 is designed to introduce the student to basic principles of a drive test. The drive test is the procedure for testing the wireless channel in real time on a predefined deployed network environment. With drive test it is also possible to create empirical propagation models for the specific scenario. The results presented in this Vlab are not established by real measurements but are based on theoretical estimation utilizing multiple diffraction theory.</p>
<p>The outcomes of the vlab#3 is to enable the student to understand:</p>
<ul>
<li>Real time wireless measurements set ups</li>
<li>GIS data</li>
<li>Propagation fit procedure based on measured field characteristics</li>
</ul>
<h4>3.2 Exercises</h4>
<h5>3.2.1 Set 1</h5>
<p>This exercise explains the procedure of a drive test. On the main figure of vlab3 click on the right part the buttons Show… to observe the positions of the transmitters. Then click on the measurement paths to observe the route of the vehicle followed to obtain the measured results.</p>
<p><strong>A.</strong> Which are the types of GIS used from wireless operators? How are they utilized for radio planning purposes?</p>
<blockquote id="Lab31A_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>GSM Second-generation (2G) cellular technology and UMTS Third-generation (3G) cellular technology&nbsp;</p>
<p>GSM is primarily focused on voice communications and basic data services, while UMTS expands on these capabilities by offering higher data speeds and enhanced multimedia services. Radio planning for both technologies involves optimizing coverage, capacity, frequency allocation, handover mechanisms, and parameters to ensure reliable and efficient mobile communication services.</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Why is it preferred to make measurements over a great variety of routes and around different base station positions on a cellular system?</p>
<blockquote id="Lab31B_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Gathering measurements over various routes and around different base station positions within a cellular system is fundamental for understanding the real-world performance of the network. It facilitates targeted improvements, optimizations, and adjustments to ensure reliable coverage, minimize interference, enhance handover procedures, and ultimately deliver better service to end-users.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Click on the Test Drive option at the menu bar and then click on the information button. With respect to the information provided explain what is the procedure for a drive test in a cellular system.</p>
<blockquote id="Lab31C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ul>
<li>A receiving antenna (Rx), that should be positioned on the vehicle's roof for better reception and less interference.</li>
<li>A standard GPS receiver recording the current position of the vehicle.</li>
<li>A sampler, which performs periodical readings of position and Rx power.</li>
<li>A standard personal computer that stores the read values to a database for subsequent manipulation.</li>
</ul>
<p>The drive test procedure involves systematically driving predefined routes while collecting Rx power readings and GPS coordinates. The collected data undergoes thorough analysis to evaluate the network's performance and identify areas for optimization, ultimately aiming to improve the overall quality and coverage of the cellular system.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>3.2.2 Set 2</h5>
<p>Click on the P.O.I button at the main figure of the GUI. By clicking on the buttons of the figure you are able to observe the geodesic path between the T<sub>x</sub> and the R<sub>x</sub> for the predefined sets of positions. The geodesic path is also called the Great Circle Path. The terrain profile and the interactions of the Rays to obtain the final field predictions are presented. In addition, canonical objects that models the terrain irregularities are also presented. These canonical objects (cylinders, Wedges or edges) are used as input to the Uniform Theory of Diffraction algorithm used for the final field predictions.</p>
<p><strong>A.</strong> Explain the concept of Fresnel Zones and justify when the signal is expected to be more attenuated in a hilly terrain like the one presented in the map of vlab 3.</p>
<blockquote id="Lab32A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<div class="flex flex-grow flex-col max-w-full">
<div class="min-h-[20px] text-message flex flex-col items-start gap-3 whitespace-pre-wrap break-words [.text-message+&amp;]:mt-5 overflow-x-auto" data-message-author-role="assistant" data-message-id="a853d582-2c40-4f12-b5d8-933135aa2696">
<div class="markdown prose w-full break-words dark:prose-invert dark">
<p>Fresnel zones are elliptical regions that exist between a transmitter and receiver in a wireless communication link. These zones play a crucial role in determining signal strength and quality, especially in scenarios where there might be obstacles or terrain variations between the transmitter and receiver.</p>
<p>In a hilly terrain like the one presented in the map of vlab 3, the concept of Fresnel zones becomes particularly important in the purlpe regions due to the potential for obstruction and interference caused by the terrain features.</p>
<ul>
<li><strong>Fresnel Zones:</strong></li>
</ul>
<p>When a wireless signal propagates between a transmitter and receiver, it doesn’t follow a straight-line path in real-world scenarios. Instead, it diffracts and spreads out, forming elliptical zones known as Fresnel zones. The first Fresnel zone is the most critical, determining the line-of-sight path between the transmitter and receiver. Subsequent zones also contribute to the signal but to a lesser extent.</p>
<p>&nbsp;</p>
<p>The signal would be most attenuated in the purlpe regions.</p>
<p><img src="userfiles/images/lab3_1_1_1.png" alt="" width="669" height="473"></p>
</div>
</div>
</div>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> From the available points of interest (P.O.I) explore and present which you believe constitutes the worst case scenario in terms of signal attenuation and which is the best scenario.</p>
<blockquote id="Lab32B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>The best is probably this one due to the small fresner zones, the clear line of sight and because they are unostructed:</p>
<p><img src="userfiles/images/lab3_1_1_4.png" alt="" width="457" height="408"></p>
<p>Probably one of the worst due to the obstructing between the Fresnel zones.:</p>
<p><img src="userfiles/images/lab3_1_1_2.png" alt="" width="479" height="413"></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Justify on the expected data rates at the specific points of interest.</p>
<blockquote id="Lab32C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>From the data taken with the drawing mode from the specific points of interest it seem like the worse power</p>
<p>is at the first run (the purlpe one), after at the second one (black), then the third (yellow) and the best at the fourth (blue) one. This is because of the terrain and because the fresner zones are less unostructed in each area relative to the previous one</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>3.2.3 Set 3</h5>
<p>Click on the Test Drive button at the menu bar. Select the GSM 02 path. On the new figure select NLOS Rice factor equal to 0 and LOS Rice factor equal to 10. (The algorithm at the LOS areas will automatically set the Rice factor equal to 10 and at the NLOS areas the Rice factor equal to 0. This was performed by a LOS test simulation. LOS means that the first Fresnel zone of the path is unobstructed by the terrain irregularities). Select the vehicle speed equal to 80Km/h and the T<sub>x</sub> and R<sub>x</sub> antenna equal to λ/2. The power boost equal to 30dBm and the R<sub>x</sub> sensitivity equal to -124dBmW. Finally set the Eb/No level equal to 20dBm and the modulation to 2 QAM. Click on the start button to observe the real time channel characteristics similar to the case of a real drive test. Click on the start button to observe the real time channel characteristics similar to the case of a real drive test.</p>
<p><strong>A.</strong> The channel analysis is based on theoretical results so there is a possibility to observe non realistic channel behaviors in certain occasions. Pinpoint and describe at least two such cases.</p>
<blockquote id="Lab33A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab3_1_1_5.png" alt="" width="742" height="189"></p>
<p>I observe non realistic power on very high distances and its probably because of the extremely high value of the power boost (30 dBm), also i observe at 17km and 35km an unrealistically stable signal strength without the expected fluctuations</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>3.2.4 Set 4</h5>
<p>This exercise will explain the procedure of creating an empirical propagation model. At the menu bar of the main GUI click on the Select Frequency button and select propagation fit. This will automatically connect to the Curve Fit tool of the simulator. At the Data button select only the Path Loss in dB and you will observe the total measured results with distance in dB. These correspond to Path Loss measurements with distance for the 4 different routes followed by the vehicle during the drive tests at GSM frequencies.</p>
<p><strong>A.</strong> Click on the Fitting option. Click on the New Fit option. Select Type of Fit Exponential <span style="font-family: 'courier new', courier, monospace;">a*exp(b*x)+c*exp(e*x)</span> and then click apply. Write down the fitting parameters observed on the dialogue box.</p>
<blockquote id="Lab34A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab3_1_1_6.png" alt=""></p>
<p>SSE = 1.597e+006</p>
<p>R-square = 0.4994</p>
<p>Adjusted R-square = 0.4992</p>
<p>RMSE = 12</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now click on the Power type of Fit The select the <span style="font-family: 'courier new', courier, monospace;">a*x^b</span> and then click apply. Write down the fitting parameters observed on the dialogue box.</p>
<blockquote id="Lab34B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab3_1_1_7.png" alt=""></p>
<p>SSE = 1.597e+006</p>
<p>R-square = 0.4992</p>
<p>Adjusted R-square = 0.4992</p>
<p>RMSE = 12</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now click on the Type of FitCustom Equation. Click on New and then select the Folder Custom Equation. Write down the equation <span style="font-family: 'courier new', courier, monospace;">a*log10(x)</span>. Write down the fitting parameters observed on the dialogue box.</p>
<blockquote id="Lab34C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab3_1_1_8.png" alt=""></p>
<p>SSE = 1.605e+006</p>
<p>R-square = 0.4967</p>
<p>Adjusted R-square = 0.4967</p>
<p>RMSE = 12.03</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Make a comparison of the simplified models you have created and comment on the most appropriate one.</p>
<blockquote id="Lab34D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ul>
<li>
<p><strong>SSE (Sum of Squared Errors):</strong></p>
<ul>
<li>The SSE values for the exponential and power-law models are the same, suggesting a similar goodness of fit. The logarithmic model has a slightly higher SSE.</li>
</ul>
</li>
<li>
<p><strong>R-square and Adjusted R-square:</strong></p>
<ul>
<li>The R-square and Adjusted R-square values are quite close for all three models. These values indicate the proportion of variance in the data that is explained by the models. The exponential model has a slightly higher R-square, suggesting a better fit.</li>
</ul>
</li>
<li>
<p><strong>RMSE (Root Mean Square Error):</strong></p>
<ul>
<li>The RMSE values are the same for the exponential and power-law models, while the logarithmic model has a slightly higher RMSE. RMSE represents the average difference between observed and predicted values, and lower values indicate better fit.</li>
</ul>
</li>
</ul>
<p><br>Based on the provided statistics, the exponential model (<span class="math math-inline"><span class="katex"><span class="katex-mathml">a⋅exp⁡(b⋅x)+c⋅exp⁡(d⋅x)</span></span></span>) appears to be slightly more appropriate for fitting the power loss over distance data. It has the lowest SSE, the highest R-square, and the lowest RMSE among the three models.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
</div>
<h1 class="_level1_page_ mceNonEditable">4 - DVB Network Planning (40Tx)</h1>
<div class="mceNonEditable">
<h4>Virtual Labs #6: DVB Network Planning (40Tx)</h4>
<h5>4.1 Description</h5>
<p>Vlabs #6 is designed to introduce to the basic principles of Radio Planning of DVB broadcast cellular systems at 600MHz. The user in this exercise has real GIS raster map available from North West part of Greece (Western Macedonia Region) and 40 possible T<sub>x</sub> positions.</p>
<p>The dark big circles represent possible transmitter T<sub>x</sub> positions and the small blue points represent villages, towns, and points of interest where DVB broadcast service is desired. Each T<sub>x</sub> has variable T<sub>x</sub> power, Gain, Cable losses. The same adjustments are supported at the R<sub>x</sub> too.</p>
<p>At the menu bar the Variables field denotes the DVB parameters such as Modulation, FFT size, Guard Interval that are required for QoS estimations.</p>
<p>The student is expected to learn basic principles of Single Frequency Network Planning and get involved with basic computations regarding C/I ratios, datarate computations, Energy efficient radio planning procedures.</p>
<p>Prior to the beginning of the exercises we encourage you to click on the Help button of the menu and explore the Legend, scenario info and other values presented. At the adaptive modulation button, the OFDM receiver of IEEE802.16 is presented supporting educational purposes.</p>
<h5>4.2 Exercises</h5>
<h6>4.2.1 Set 1</h6>
<p>This exercise introduces to coverage and bitrate estimation for the case of a network with few transmitters. The main goal is to understand the concept of interference in SFN networks due to Guard interval value and to observe the QoS and datarates for different modulation schemes. Click on the <span style="font-family: 'courier new', courier, monospace;">Selection Mode</span> of the menu bar the <span style="font-family: 'courier new', courier, monospace;">Select Single Node</span> and <span style="font-family: 'courier new', courier, monospace;">Select Transmitters only</span> fields. Position the cursor on top of T<sub>x3</sub> in the middle of the GIS map and click. On the bottom right part you can change the T<sub>x</sub> power, cable losses, etc of the T<sub>x</sub>. Keep the default values and just click on the is Active button to activate the T<sub>x</sub>. Then go again to the Selection mode and click on the <span style="font-family: 'courier new', courier, monospace;">Select Receivers only</span>. Go to the receiver shown in the figure and click on top of it. On the top right part of the GUI you can see all the available data for the R<sub>x</sub>. This include the C/N, C/I, bitrate, gain, noise level, position.</p>
<p><img src="userfiles/images/DVBrxtx.png" alt="" width="613" height="407"></p>
<p><strong>Α.</strong> Write down the values of bit rate, the C/I, the C/N.</p>
<blockquote id="Lab61A_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Bitrate : 5.85 Mbps</p>
<p>C/I : 74.4211 db</p>
<p>C/N : 74.4211 db</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>Β.</strong> Click on the button <span style="font-family: 'courier new', courier, monospace;">Show Delays, Path, GI window coverage</span> and write down the delays and the received power from T<sub>x3</sub>.</p>
<blockquote id="Lab61B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_1.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now go to Variables/global and change the QPSK modulation to 64QAM and close the box dialogue. You will observe that the bitrate has changed. Write down the value.</p>
<blockquote id="Lab61C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Bitrate : 17.56 Mbps</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Change the modulation again back to QPSK. Now click on the Received Power/Coverage button on the lower part of the GUI and observe how many towns are covered by the antenna. Write down the percentage of coverage.</p>
<blockquote id="Lab61D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_2.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Now go to the Selection Mode, click Select Multiple then click Select Transmitters only and click on T<sub>x12</sub> of the GUI. At the dialogue box on the lower right part of the GUI click on the Is Active. Keep all other parameters to the default values. Now go the selection mode, click on Select single Node and click on Select Receivers only. Click again on the same R<sub>x</sub> as the previous case (only T<sub>x3</sub>). You will observe a change on the QoS on the picture. What is the reason for the degradation of the signal quality?</p>
<blockquote id="Lab61E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_3.png" alt=""></p>
<ul>
<li>
<p><strong>Signal Interference:</strong></p>
<ul>
<li>The presence of external interference, such as electromagnetic interference from other devices Tx3, can degrade signal quality. Interference can introduce noise and disrupt the communication signal.</li>
</ul>
</li>
<li>
<p><strong>Increased Path Loss:</strong></p>
<ul>
<li>As the distance between the transmitter and receiver increases, the signal experiences path loss.</li>
</ul>
</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> Write down all the values for the receiver position, datarate, C/I,C/N. What do you observe on the C/I value?</p>
<blockquote id="Lab61F_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Bitrate : 5.8107 Mbps</p>
<p>C/I : 19.9842 db</p>
<p>C/N : 74.0632 db</p>
<p>&nbsp;</p>
<p>I can observe that the carrier signal power to the interference power droped and now it is about 19.98 decibels stronger than the interference.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>G.</strong> Now click on the <span style="font-family: 'courier new', courier, monospace;">Show Delays, Path… </span>button on the lower part of the GUI and observe the signal arriving from T<sub>x12</sub>. Explain why this is an interferer.</p>
<blockquote id="Lab61G_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_4.png" alt="" width="728" height="523"></p>
<p>The Tx12 is considered an interferer because its delayed and further away but has the same frequency, which introduces interferances in the signal produced by the Tx3 because of multipath fading and intersymbol interference (ISI) .</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>H.</strong> Go to the menu bar, Variables/global change the Guard Interval from 0.0625 to 0.25. Close the box and you will observe the quality of the new picture. It is perfect. Explain the reason.</p>
<blockquote id="Lab61H_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_5.png" alt="" width="752" height="400"></p>
<p>Now the picture is transmitted perfectly, the reason this happens is because of the guard interval which now stops the Multipath Fading and Intersymbol Interference from the Tx12 transmitter by inserting a period of time between symbols or data packets in a communication system which now is higher. the effects are visible also in the green circle in the map of delays...</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>I.</strong> Go to the <span style="font-family: 'courier new', courier, monospace;">Show Delays, Path… </span>button on the lower part and click. You will see that the signal from T<sub>x12</sub> is within the Guard Interval of the signal. Click on the Received Power/Coverage button and write down the coverage percentage obtained by the small network of T<sub>x3</sub> and T<sub>x12</sub>.</p>
<blockquote id="Lab61I_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_6.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>J.</strong> Based on the values of the received power from the signals arriving from T<sub>x</sub><sub>3</sub> and T<sub>x12</sub> compute C/I and compare with the value given by the simulation. (The following formulas are provided for ease)</p>
<p style="text-align: center;"><img src="userfiles/images/FomulasReceptWindowCIComp.png" alt="" width="732" height="86"></p>
<blockquote id="Lab61J_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ul>
<li style="list-style-type: none;">
<ul>
<li>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.13889em;">T</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><sub><span class="vlist" style="height: 0.1514em;"><span style="top: -2.55em; margin-left: -0.1389em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mathnormal mtight">u</span></span></span></span></sub><span class="vlist-s">​</span></span></span></span></span></span></span></span></span>: Symbol duration - The time it takes to transmit one symbol.</p>
</li>
<li>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">T<sub>GI</sub></span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​</span></span></span></span></span></span></span></span></span>: Guard interval duration - A period of time inserted between symbols to mitigate intersymbol interference.</p>
</li>
<li>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">t</span></span></span>: Time variable - Represents the time within the window.</p>
</li>
<li>
<p><span class="math math-inline"><span class="katex"><span class="katex-mathml">T<sub>f</sub></span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​</span></span></span></span></span></span></span></span></span>: End time of the window - The duration of the window.</p>
</li>
</ul>
<ul>
<li>Channel Spacing (<span class="math math-inline"><span class="katex"><span class="katex-mathml">Tu</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​</span></span></span></span></span></span></span></span></span>): 8,000,000 Hz</li>
<li>Client noise level (<span class="math math-inline"><span class="katex"><span class="katex-mathml">noise_level_kTB_DBW</span></span></span>): -135.5 dBW</li>
<li>Coding Rate: 1/2</li>
<li>FFT Size: 2,048</li>
<li>Frequency (<span class="math math-inline"><span class="katex"><span class="katex-mathml">Frequency_Hz</span></span></span>): 600,000,000 Hz</li>
<li>Guard Interval (<span class="math math-inline"><span class="katex"><span class="katex-mathml">Tgi</span><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​</span></span></span></span></span></span></span></span></span>): 0.25 seconds</li>
</ul>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.13889em;">T</span><span class="msupsub"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.1514em;"><span style="top: -2.55em; margin-left: -0.1389em; margin-right: 0.05em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mathnormal mtight">u</span></span></span></span><span class="vlist-s">​</span></span></span></span></span><span class="mrel">=1/</span></span><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist" style="height: 0.8451em;"><span style="top: -2.655em;"><span class="sizing reset-size6 size3 mtight"><span class="mord mtight"><span class="mord text mtight">Channel&nbsp;Spacing</span></span></span></span> =&gt;</span><span class="vlist-s">​</span></span></span></span></span></span></span></span></span> <span class="math math-inline"><span class="katex"><span class="katex-mathml">Tu=1/8,000,000&thinsp;Hz = 0,125 Hz</span></span></span></p>
<p>For t = 23.6410 msec</p>
<p>w(t) = ((T_u - t + T_gi) / T_u)^2<br>w(23.6410 msec) = ((0.125 - 23.6410 × 10^-3 + 0.25) / 0.125)^2<br>w(23.6410 msec) = 7.9010014 s</p>
<p>For t = 100.9110 msec</p>
<p>w(t) = ((T_u - t + T_gi) / T_u)^2<br>w(100.9110 msec) = ((0.125 - 100.9110 × 10^-3 + 0.25) / 0.125)^2</p>
<p>w(100.9110 msec) = 4.807985915 s</p>
<p>&nbsp;</p>
<p>w(t) = ((T_u - t + T_gi) / T_u)^2<br>w(100.9110 msec-23.6410 msec) = ((0.125 - 77.27 × 10^-3 + 0.25) / 0.125)^2</p>
<p>w(77.27 msec) = ((0.125 - 77.27 × 10^-3 + 0.25) / 0.125)^2 = 5.673161786 sec</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​C/I = P_w / (P_u + N_0) =&nbsp; -61.0789+(-81.0631)/((1-(-61.0789+(-81.0631)))-135.5) = −71.686476551 db<br></span></span></span></span></span></span></span></span></span></p>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​C/I = P_w / (P_u + N_0) =&nbsp; P* w(t)/ (P*(1-w(t)) + N_0)<br></span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">=&nbsp; (-61.0789+(-81.0631))*5.673161786/((-61.0789+(-81.0631))*(1-(5.673161786)))-135.5) = −136,713987884db</span></span></span></span></span></span></span></span></span></p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mord mathnormal" style="margin-right: 0.13889em;">&nbsp;</span></span></span></span></span></span></p>
</li>
</ul>
<p>&nbsp;</p>
<p><span class="math math-inline"><span class="katex"><span class="katex-html" aria-hidden="true"><span class="base"><span class="mord"><span class="mfrac"><span class="vlist-t vlist-t2"><span class="vlist-r"><span class="vlist-s">​</span></span></span></span></span></span></span></span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>4.2.2 Set 2</h5>
<p>This exercise introduces to energy efficient radio planning of SFN networks. For the previous network setup (T<sub>x3</sub> and T<sub>x12</sub>) with 30dBW T<sub>x</sub> power click on the Carbon dioxide emission per T<sub>x</sub> button and write down the produced Tons of CO<sub>2</sub> emission caused by this network configuration. The values are based on real tabulated values presented in the figure below assuming 1KWh~800grCO<sub>2</sub>.</p>
<p><img style="display: block; margin-left: auto; margin-right: auto;" src="userfiles/images/TableCO2.png" alt="" width="365" height="230"></p>
<p><strong>A.</strong> Click on the Select Mode/select Multiple/select T<sub>x</sub> only/ and click on T<sub>x</sub> with numbers 15, 34, 8, 17. Click on the Is active button and change the Power (dBW) of ALL T<sub>xs</sub> to be equal to 20dBW instead of 30dBW. Now click on the Received Power/coverage button and write down the percentage value. Compare it to the network of T<sub>x3</sub> and T<sub>x12</sub> with power out of 30dBW each.</p>
<blockquote id="Lab62A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_10.png" alt=""><img src="userfiles/images/lab4_1_1_9.png" alt=""></p>
<p>I can see that the 4 Tx transmitter with 20dbW power consume almost 25% less carbon dioxide per year</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now click on the Carbon dioxide emissions per T<sub>x</sub> button and write down the total carbon emissions in Tons/year. Compare to the case of the network configuration with T<sub>x3</sub> and T<sub>x12</sub> with power 30dBW. What is the main conclusion?</p>
<blockquote id="Lab62B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab4_1_1_11.png" alt=""></p>
<p>We have almost the same coverage</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h5>4.2.3 Set 3</h5>
<p>A network operator wants to deploy a DVB T network over the GIS data provided. It has 40 possible T<sub>x</sub> positions with variable T<sub>x</sub> power. The OFDM parameters of the DVB network is It is wanted that 85% of the villages, towns and cities of the GIS map requires coverage. Two cases should be examined for the network operator:</p>
<ul>
<li>Case 1—The network should be designed in such a way to provide minimum CAPEX. This is the network with the minimum number of T<sub>x</sub>.</li>
<li>Case 2—The network should be designed in such a way to provide minimum OPEX. This is the network with the minimum carbon emissions. It is assumed that carbon emissions are directly translated to Euros/KWh.</li>
</ul>
<p>Write a full report, justifying your steps of the planning process for the two cases and provide all the required figures to justify your answers. (<em><span style="color: #993300;">~1000 words excluding Figures is the average size of the correct answer to this question! It also gets a good part of the overall grade</span></em>).</p>
<blockquote id="Lab63B_c1_w2" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Case 1:</p>
<p>Initially i will consider the GIS data to identify the locations of villages that need coverage. I will determine their distribution and density from the map. Next i will identify key strategic locations for transmitter (Tx) placement based on GIS data, coverage requirements topology and geography. Next i will optimize the Tx power levels to achieve the desired coverage with the minimum number of transmitters. Lastly i will need to design the network topology and connectivity to ensure coverage for 85% of the identified locations with the minimum number of transmitters.</p>
<p>After a lot of trial and error i discovered that the biggest factor in overall coverage is the initial power of the transmitter, as case 1 wants the network with the minumum number of transimiter that produce a coverage of 85%, i choose the most centre transmitter i.e Tx8 and i changed the overall power from 30dbW to 95dbW which gives an overall coverage of 86%. The exercise does not specify a specific power which would be considered heathly for the populous or legal. So the easiest way to achieve a high coverage with one and only one transmitter anyware in the map is to blast the map with enough power.</p>
<p>&nbsp;</p>
<p>These provides the minimum CAPEX if we consider the CAPEX to be the minimum number of transmitters but in no way it is cost effective which is a basic consideration of any design.</p>
<p>&nbsp;</p>
<p><img src="userfiles/images/lab4_1_1_13.png" alt="" width="756" height="399"></p>
<p>&nbsp;</p>
<p>Case 2:</p>
<p>Here based on the previous knowledge i started by enabling all the transmitters and setting their power lower from 30 dbW to 15 dbW which resuslted in an overall coverage of 92% with carbon emissions at 223 tons/year.</p>
<p><img src="userfiles/images/lab4_1_1_14.png" alt="" width="705" height="374"></p>
<p>&nbsp;</p>
<p>Then i will lower it more until i get the 85% overall with the least possible power. At 10dbW i get 151c02/year which a big decrease in overall co2 emmission even though i still get an overall 90% coverage.</p>
<p><img src="userfiles/images/lab4_1_1_15.png" alt="" width="709" height="378"></p>
<p>Now i will reduce it to 5dbW getting even lower co2 per year with still acceptablle coverage 88%</p>
<p><img src="userfiles/images/lab4_1_1_16.png" alt="" width="741" height="388"></p>
<p>I will lower it even more at 0.1 dbW getting an even lower co2 per year with still acceptablle coverage 87%</p>
<p><img src="userfiles/images/lab4_1_1_17.png" alt="" width="709" height="370"></p>
<p>Further decreasing the power doesnt result in any significant lowering of the CO2 tons per year .</p>
<p>So now to further decrease the co2 emissions i will reduce the number of transmitter. Starting with the transmiters that doesnt infuence the coverage so much because of their remoteness and the topology and later with transmitters that produce noise.</p>
<p>Closing the trasmitter that are already in regions that the signal isnt present and the towns are presented in red by the coverage map i.e transmitters 24,36,37,40</p>
<p>Now i reach 107tons per year with almost the same coverage.</p>
<p><img src="userfiles/images/lab4_1_1_18.png" alt=""></p>
<p>Further i am closing transmitters that may cause interferences and doesnt contribute to the overall coverage because of the transmitters around them that cover for them i.e.(24,12,32,11,13,18,20)</p>
<p>In the end through trial and error i reach the final topology by remove trasmitters that doesnt contribute to the coverage or their contribution is miniscule e.g.(1,5,9,15,19,25,26,28,33,29,10,30,34,23)</p>
<p>&nbsp;</p>
<p>Final results:<br><img src="userfiles/images/lab4_1_1_19.png" alt=""></p>
<p>Final Topology:</p>
<p><img src="userfiles/images/lab4_1_1_20.png" alt=""></p>
<p>&nbsp;</p>
<p>It is evident that there is a big decrease in cost and overall co2/year as in the final topology i reached 51 tons of co2 with 85% coverage.</p>
<p>&nbsp;</p>
<p>This result its not reached through an algorithm but by some heuristics and trial and error, so there can be a better solution than what i achieved.</p>
<p>&nbsp;</p>
<p>As a final conclusion if the cost of building transmitters is not very high then OPEX solution is much better than the CAPEX one as the costs running the operation are extremely lower</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
<p>&nbsp;</p>
</blockquote>
<p>&nbsp;</p>
</div>
<h1 class="_level1_page_ mceNonEditable">5 - DVB Network Planning (13Tx)</h1>
<div class="mceNonEditable">
<h3>Virtual Labs #7: DVB Network Planning (13Tx)</h3>
<h5>5.1 Description</h5>
<p>Vlabs #7 is similar to vlabs#6 but the network configuration to the user is the energy efficient network configuration obtained by Genetic algorithm optimization procedure. In addition, some new aspects of radio planning are presented and the simulation results do not target specific villages, towns or points of interest of the GIS map but they are represented as a meshgrid with spacing of 500m. In this way there is the ability to observe surface results and have a clear picture concerning the effect of variable network planning parameters.</p>
<h5>5.2 Exercises</h5>
<h6>5.2.1 Set 1</h6>
<p>Click on Mass selection button /Transmitter. Set the following T<sub>x</sub> power for the T<sub>x</sub> and click on the is Active button.</p>
<table>
<tbody>
<tr>
<td>
<p>T<sub>x1</sub>=36dBW</p>
<p>T<sub>x2</sub>=26dBW</p>
<p>T<sub>x3</sub>=20dBW</p>
<p>T<sub>x4</sub>=26dBW</p>
<p>T<sub>x5</sub>=36dBW</p>
<p>T<sub>x6</sub>=20dBW</p>
<p>T<sub>x7</sub>=26dBW</p>
</td>
<td>
<p>T<sub>x8</sub>=20dBW</p>
<p>T<sub>x9</sub>=20dBW</p>
<p>T<sub>x10</sub>=20dBW</p>
<p>T<sub>x11</sub>=20dBW</p>
<p>T<sub>x12</sub>=20dBW</p>
<p>T<sub>x13</sub>=26dBW.</p>
</td>
</tr>
</tbody>
</table>
<p>Do not change the default values of the Global Variables.</p>
<p>Click on the selection mode/single node/select any. Place the cursor on different positions on the GIS map and observe that the signal quality is not acceptable. Explore the network performance by clicking the cursor on any position on the GUI map and observe the girl in the picture. You will see that the reception is poor. For any position of your choice click on the <span style="font-family: 'courier new', courier, monospace;">Show Delays, Path…</span>&nbsp;button at the lower part of the GUI and observe the Useful and Interfering signals arriving from different Txs.</p>
<p><strong>A.</strong> Which is the reason that the reception is poor? Explain.</p>
<blockquote id="Lab71A_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab5_1_1_20.png" alt="" width="755" height="573"></p>
<p>&nbsp;</p>
<p>Wherever the transmiters are inside the circle the picture cant be transmitted well because of interference, multipath fading, etc. When we have lower power from some stations these results will be less visible with better signal quality. We can increase the guard in order to get a better signal.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>5.2.2 Set 2</h6>
<p><strong>A.</strong> For the reception point of your interest compute the C/I and compare to the obtained value by the simulation. Now click on the Global variables and set the parameters like as follows:</p>
<ul>
<li>Channel_spacing_Hz=8,000,000,</li>
<li>Client_noise_level_k=-135.5,</li>
<li>Coding_rate=1/2,</li>
<li>FFT_size=8192,</li>
<li>Frequency_Hz=600,000,000,</li>
<li>Guard_Interval=0.5,</li>
<li>Modulation=64QAM.</li>
</ul>
<p>Click the cursor on any positions of your interest on the GIS map and describe the signal quality (girl picture).</p>
<blockquote id="Lab72A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>There is mistake in the guard interval because the lab enviroment cant take as guard=0.5, it is assumed that the right one is 0.25.</p>
<p>&nbsp;</p>
<p>C/I = -10,6857 db</p>
<p>&nbsp;</p>
<p>new C/I after the changes C/I = 66.0296 db.</p>
<p>&nbsp;</p>
<p>The signal quality has gotten better because of the increased guard and the fft which contributes in the w(t) function in the T<sub>u</sub></p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> For the same reception point like in (A) above, compute the C/I value. Now click on the received Power button at the lower part of the GUI and observe the effect of the terrain to signal strength. Now click on the C/I button and observe the C/I obtained by the simulation. At the Global variables reduce the guard Interval to 0.0625 (which is the minimum) and click again the C/I button. Observe and comment on the produced figures.</p>
<blockquote id="Lab72B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>new C/I after the changes C/I = 66.0296 db.</p>
<p><img src="userfiles/images/lab5_1_1_1.png" alt=""></p>
<p><img src="userfiles/images/lab5_1_1_2.png" alt=""></p>
<p>Guard = 0.0625</p>
<p><img src="userfiles/images/lab5_1_1_3.png" alt=""></p>
<p>As i can observe from the graphs the lowering of the guard value decreases the C/I in the map</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Perform the same observations for the Coverage estimations (Coverage button at the lower part of the GUI) by setting the TGI=0.0625 and TGI=0.25. When is the network interference limited?</p>
<blockquote id="Lab72C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab5_1_1_4.png" alt="" width="755" height="336"></p>
<p>in figure 3 the guard is 0.25 and in figure 2 the guard is 0.0625 as i can see the network interferance is limited when we lower the guard</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Now press on the SI button. SI stands on the Safety Index which is the percentage of exposure to RF radiation based on the European Thresholds. The SI value holds an important role to the network planning strategy since the European Union has imposed strict rules concerning RF exposure. SI is defined as the sum of the ratios of the computed power density at every frequency for a given receiver position over the threshold value. In many countries, like in Greece, the maximum threshold value is 60% of the threshold value indicated by the EU. This value is computed according to (for the frequency range between 400-2000MHz).</p>
<p style="text-align: center;"><img src="userfiles/images/eq1.png" alt=""></p>
<p>The SI for a given receiving point caused by a transmitter, j, operating at frequency fi is given by</p>
<p style="text-align: center;"><img src="userfiles/images/eq2.png" alt=""></p>
<p>For the purpose of our investigation, the transmitters are operating at fi=600MHz. The total exposure at a given receiving location caused by N transmitters equals</p>
<p style="text-align: center;"><img src="userfiles/images/eq3.png" alt=""></p>
<p>You can now adjust the values of Tx power, Guard Interval and observe the effect on the SI, C/I, Coverage, Received Power. Observe the variations and comment.</p>
<blockquote id="Lab72D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<div class="flex flex-grow flex-col max-w-full">
<div class="min-h-[20px] text-message flex flex-col items-start gap-3 whitespace-pre-wrap break-words [.text-message+&amp;]:mt-5 overflow-x-auto" data-message-author-role="assistant" data-message-id="eb18ffdb-5a74-41d0-93bc-e70a66c32deb">
<div class="markdown prose w-full break-words dark:prose-invert dark">
<h3>Tx Power:</h3>
<ol>
<li>
<p><strong>Signal-to-Interference (SI) and Carrier-to-Interference (C/I):</strong></p>
<ul>
<li><strong>Increase in Tx Power:</strong>
<ul>
<li><strong>SI:</strong> Higher Tx power leads to stronger signals, improving SI.</li>
<li><strong>C/I:</strong> Higher Tx power can improve C/I ratio, as the desired signal becomes stronger relative to interference.</li>
</ul>
</li>
<li><strong>Decrease in Tx Power:</strong>
<ul>
<li><strong>SI:</strong> Lower Tx power leads to weaker signals and potentially lower SI.</li>
<li><strong>C/I:</strong> Lower Tx power decrease the C/I ratio, making the system more susceptible to interference.</li>
</ul>
</li>
</ul>
</li>
<li>
<p><strong>Coverage:</strong></p>
<ul>
<li><strong>Increase in Tx Power:</strong>
<ul>
<li>Higher Tx power can extend coverage to a larger area.</li>
</ul>
</li>
<li><strong>Decrease in Tx Power:</strong>
<ul>
<li>Lower Tx power results in reduced coverage, especially in distant or obstructed areas.</li>
</ul>
</li>
</ul>
</li>
<li>
<p><strong>Received Power:</strong></p>
<ul>
<li><strong>Increase in Tx Power:</strong>
<ul>
<li>Higher received power at the receiver due to the stronger transmitted signal.</li>
</ul>
</li>
<li><strong>Decrease in Tx Power:</strong>
<ul>
<li>Lower received power at the receiver due to the weaker transmitted signal.</li>
</ul>
</li>
</ul>
</li>
</ol>
<h3>Guard Interval:</h3>
<ol>
<li>
<p><strong>Signal-to-Interference (SI) and Carrier-to-Interference (C/I):</strong></p>
<ul>
<li><strong>Increase in Guard Interval:</strong>
<ul>
<li>Longer guard intervals mitigates intersymbol interference, improving SI.</li>
<li>It may also improve C/I by reducing the impact of multipath interference.</li>
</ul>
</li>
<li><strong>Decrease in Guard Interval:</strong>
<ul>
<li>Shorter guard intervals leads to increased intersymbol interference, reducing SI.</li>
<li>It also decreases C/I if multipath interference becomes more significant.</li>
</ul>
</li>
</ul>
</li>
<li>
<p><strong>Coverage:</strong></p>
<ul>
<li><strong>Increase in Guard Interval:</strong>
<ul>
<li>Longer guard intervals helps maintain signal integrity over longer distances, improving coverage.</li>
</ul>
</li>
<li><strong>Decrease in Guard Interval:</strong>
<ul>
<li>Shorter guard intervals results in coverage limitations, especially in challenging propagation environments.</li>
</ul>
</li>
</ul>
</li>
<li>
<p><strong>Received Power:</strong></p>
<ul>
<li><strong>Increase in Guard Interval:</strong>
<ul>
<li>Longer guard intervals might lead to higher received power due to better signal integrity.</li>
</ul>
</li>
<li><strong>Decrease in Guard Interval:</strong>
<ul>
<li>Shorter guard intervals might result in lower received power due to increased interference and potential signal degradation.</li>
</ul>
</li>
</ul>
</li>
</ol>
<h3>Observations and Comments:</h3>
<ul>
<li>
<p><strong>Tx Power:</strong></p>
<ul>
<li>Balancing Tx power is crucial to achieving desired coverage and maintaining signal quality.</li>
<li>Higher Tx power improves coverage but increases interference in dense deployments.</li>
</ul>
</li>
<li>
<p><strong>Guard Interval:</strong></p>
<ul>
<li>Guard intervals play a critical role in mitigating interference and maintaining signal integrity.</li>
<li>Longer guard intervals are beneficial in challenging environments, but they reduce data rate.</li>
</ul>
</li>
</ul>
</div>
</div>
</div>
<div class="mt-1 flex justify-start gap-3 empty:hidden">
<div class="text-gray-400 flex self-end lg:self-center justify-center lg:justify-start mt-0 -ml-1 visible">&nbsp;</div>
</div>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Finally click on the Single Frequency Gain. What do you observe?</p>
<blockquote id="Lab72E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab5_1_1_5.png" alt=""></p>
<p>&nbsp;I observe that the single frequency gain is at zero excluding only a few small areas.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> What is the Single Frequency Gain?</p>
<blockquote id="Lab72F_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><span class="ILfuVd" lang="en"><span class="hgKElc">The single gain frequency is <strong>the frequency at which the gain is 0dB (1x)</strong>, while the GB product is the product of the gain (unit: times) and frequency. Therefore, ideally the gain-bandwidth product and single gain frequency will be the same value.</span></span></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
</div>
<h1 class="_level1_page_ mceNonEditable">6 - Indoor Network Planning</h1>
<div class="mceNonEditable">
<h4>Virtual Labs #8: Indoor Network Planning</h4>
<h5>6.1 Description</h5>
<p>Vlabs #8 introduces the student to deterministic channel estimations based on ray tracing algorithm and on basic principles for indoor network planning at 2.4GHz. At the menu bar of the GUI the Pick up scenario button offers the ability to choose between Scenario 1 and Scenario 2.</p>
<p><em>Scenario 1</em> refers to deterministic channel estimations whereas scenario 2 refers to indoor network planning (WLAN or femtocells). The indoor environment comprises walls (brick), doors (wood) and windows (glass) and different T<sub>x</sub> positions operating at 2.4GHz frequency.</p>
<p>The aim of Scenario 1 of the vlab is to compute in a deterministic way the channel variations in an indoor environment. The user has the ability to pick up a Rx point in the indoor environment (bottom left figure of GUI) and simulate RMS delay spread, Rice factor, field strength according to ray tracing results. In addition, the user has the ability to define the number of interactions between the propagating rays from the Tx to the Rx point. In this way, the user can deeply understand the basic elements of the channel (multipaths-Rays).</p>
<p>The aim of <em>Scenario 2</em> is to introduce the user to the basic principles of indoor radio network planning. These can be WLAN or femtocell systems. Scenario 2 is divided into 3 categories:</p>
<p><span style="text-decoration: underline;">Generic Network</span>. This category presents basic results regarding coverage estimations in indoor networks. These are Received Field, CINR, Coverage and Best Server Plots</p>
<p><span style="text-decoration: underline;">OFDM Network</span>. This category assumes a network of OFDM system. The user can set:</p>
<ul>
<li>N of subcarriers- This is the total number of subcarriers.</li>
<li>Subacrriers per user- This value is used to compute the transmitted power by the AP for the user.</li>
<li>Collision probability- This value is a simplified version of a resource allocation scheme. For instance, if it is equal to 0 it means that in the network each user occupies totally different subcarriers to the transmitted subcarriers by neighboring APs. Interference is 0 and vice versa.</li>
<li>Sampling Rate- used for noise floor estimation.</li>
</ul>
<p>Then the Monte Carlo inputs are defined. The Monte Carlo used is simplified and the user can set the number of independent runs, the minimum number of users and the maximum number of users. In each run the simulation randomly selects a value between Min User and Max User and then place the users randomly in the network. For this topology the results obtained are:</p>
<ul>
<li>Outage Probability- the number of users could not assigned to an AP due to SINR values or capacity (maximum 4 users per AP was assumed)</li>
<li>SINR effective- the histogram of the SINR effective values obtained</li>
<li>Adaptive Modulation index- Histogram of the number of users assigned to QPSK, 16 QAM and 64 QAM.</li>
<li>Tx power from Mobile Devices- is the histogram of the mean transmitted power from the Mobile Devices to communicate to the APs. (a Mobile user was assumed to have max RF out=25dBm)</li>
</ul>
<p><span style="text-decoration: underline;">CDMA Network</span>. This category assumes a CDMA network. The user can define the following parameters:</p>
<ul>
<li>Chip Rate- bandwidth for CDMA</li>
<li>Bit rate- bit rate of service</li>
<li>Orthogonality- orthogonality of codes (1 is totally orthogonal and 0 means no orthgonality)</li>
<li>Eb/I- the threshold of Eb/I</li>
<li>User’s T<sub>x</sub> power- this is the power assigned by the base station (AP) for the user. It MUST be always smaller than the maximum out power of the AP.</li>
</ul>
<p>The general parameters that the user can adjust are:</p>
<ul>
<li>Noise Figure</li>
<li>Noise Temperature</li>
<li>Bandwidth</li>
<li>By clicking on the Setup T<sub>x</sub> button of the GUI the user can change the T<sub>x</sub> power of the selected AP and the Antenna Gains (Omnidirectional).</li>
</ul>
<h5>6.2 Exercises</h5>
<h6>6.2.1 Set 1</h6>
<p>On the Menu Bar go to Pick up a Scenario and select Scenario 1. Set the Number of ray interactions equal to 8. Then click on the Pick a Rx Point/then click the cursor on a position on the indoor environment and click on the PDP at Point button.</p>
<p>You can now observe the propagating rays reaching the Rx from the Tx. These rays constitute the multipaths that characterize the wireless channel. For the same Rx point you can now reduce the number of interactions from 8 to 7 using the slider button of the GUI. Observe the new rays.</p>
<p><strong>A.</strong> Use the slider and reduce the number of ray interactions until there is an error message on your workspace. Comment on the channel variation using the number of the ray interactions.</p>
<blockquote id="Lab81A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ol>
<li>
<p><strong>Decreasing Ray Interactions:</strong></p>
<ul>
<li>As you decrease the number of ray interactions, the model becomes less complex, representing fewer distinct paths that the signal can take from the transmitter to the receiver.</li>
</ul>
</li>
<li>
<p><strong>Effect on Multipath Fading:</strong></p>
<ul>
<li>Multipath fading is less pronounced with fewer ray interactions. A higher number of ray interactions provides a more detailed representation of the variations in signal strength caused by constructive and destructive interference among different paths.</li>
</ul>
</li>
<li>
<p><strong>Impact on Channel Impulse Response:</strong></p>
<ul>
<li>The channel impulse response becomes less intricate as the number of ray interactions decreases. The impulse response describes how the channel responds to a short pulse, and a more complex impulse response corresponds to a more complex channel.</li>
</ul>
</li>
</ol>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> The scope now is to observe how the Rice factor and the RMS delay spread vary with the R<sub>x</sub> position. The user can also compute by hand the values and compare to the obtained values by the simulation. It is mentioned that the delays are all in nsecs and the Rice factor is in linear values. Pick up a R<sub>x</sub> point at the left part of the corridor where there is LOS with the Access Point. Click on PDP at point. What do you observe? Write down the Rice Factor and the Delay values.</p>
<blockquote id="Lab81B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ol>
<li>
<p><strong>Rice Factor:</strong></p>
<ul>
<li>The Rice factor is a measure of the strength of the LOS component relative to the scattered components in a wireless channel. If there is clear LOS with the Access Point, the Rice factor is high.</li>
</ul>
</li>
<li>
<p><strong>Delay Values:</strong></p>
<ul>
<li>The delay values represent the time differences between the direct LOS path and the various scattered paths that contribute to the received signal. The RMS delay spread provides a measure of the spread of these delays.</li>
</ul>
</li>
</ol>
<p>For the selected point i have delays for 7 rays :</p>
<p>&nbsp;</p>
<p>0.0076465,06.7237, -11.63111.528,-22.32921.028,-25.16432.292,-54.64534.365, -35.94736.397, -33.73538.12,-34.04839.948,....</p>
<p>K-factor : 30</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Now pick up a point on the bottom right room under the T<sub>x</sub>&nbsp; AP and click again on the PDP at Point button of the GUI. Write down the Rice factor and Delays obtained by the simulation. What is the waveguiding effect of the corridors?</p>
<blockquote id="Lab81C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Delays : 0.0023108,010.788,-33.97814.838,-14. 52229. 507, -46.84831.835, -23.5636.817,-21.43350.671,-54.4261.466,-43.529</p>
<p>K factor : 55</p>
<ul>
<li>
<p><strong>Signal Confinement:</strong></p>
<ul>
<li>Corridors act as enclosed spaces that confine and guide radio waves. The walls of the corridor act as reflective surfaces, and the signals can bounce off these surfaces, leading to waveguiding.</li>
</ul>
</li>
<li>
<p><strong>Multipath Propagation:</strong></p>
<ul>
<li>The waveguiding effect in corridors result in multipath propagation, where signals take multiple paths due to reflections. This leads to constructive or destructive interference, affecting the received signal strength.</li>
</ul>
</li>
<li>
<p><strong>Impact on Channel Characteristics:</strong></p>
<ul>
<li>The waveguiding effect contributes to the channel characteristics within a corridor. The channel impulse response, delay spread, and Ricean or Rayleigh fading characteristics may be influenced by the waveguiding effect.</li>
</ul>
</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Why is the Rice factor smaller for the case of R<sub>x</sub> placed on the LOS region with the T<sub>x</sub> (on the corridors) in comparison to the case the R<sub>x</sub> is NLOS with the R<sub>x</sub> in the room?</p>
<blockquote id="Lab81D_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Where the Rx (receiver) is placed in the LOS region with the Tx (transmitter) in the corridors compared to the case where the Rx is in the non-line-of-sight (NLOS) region with the Tx in the room, the differences in Rice factor can be explained by the presence of in the case of LOS multipaths which make the Rice factor smaller and the NLOS by the absence of those multipaths which cannot overcome the wave even though the signal can, which results in a a higher k factor</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Where do you expect the channel to be more narrowband for the two R<sub>x</sub> positions?</p>
<blockquote id="Lab81E_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>Where the k factor is higher i expect a more narrow band channel. In the case of the two positions the down right room will have a more narrowband channel compared to the other one</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.2 Set 2</h6>
<p><strong>A.</strong> Pick the R<sub>x</sub> point. Select 5 interaction rays on the slider and click on the PDP at Point button. You must see the power delay profile and the rays. From the power delay profile, compute the Total Excess Delay and the RMS Delay and compare it to the values obtained by the simulation. You can use the data cursor to obtain the exact values of the relative received power of each tap and the delay.</p>
<blockquote id="Lab82A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab5_1_1_6.png" alt="" width="672" height="528"></p>
<p>&nbsp;</p>
<p>Total Excess Delay:</p>
<ul>
<li>The Total Excess Delay is the sum of the time delays of all significant taps in the PDP:</li>
<li>
<div>
<div>Total Excess Delay = Σ (P_i * τ_i), for i = 1 to N</div>
</div>
<p>Where:</p>
<ul>
<li>N is the total number of significant taps.</li>
<li><span aria-hidden="true">Pi​</span> is the relative received power of the i<span aria-hidden="true">i</span>-th tap.</li>
<li><span aria-hidden="true">τi​</span> is the time delay of the i<span aria-hidden="true">i</span>-th tap.</li>
</ul>
</li>
</ul>
<p>Total Excess Delay = Σ (P_i * τ_i), for i = 1 to N =&gt;</p>
<p>=&gt; 0 + 7,018*-26,84 + -11,63*9,151 + 21,34*-17,1 + 25,62*-14,77 = −1038,1107 db*sec</p>
<p>The RMS Delay is the root mean square of the time delays of the significant taps:</p>
<div>
<ul>
<li>RMS Delay = sqrt(Σ (P_i * (τ_i - τ̄)^2) / N) =&gt;&nbsp; (τ̄ = −207,62214 sec) =&gt;</li>
</ul>
<p>=&gt; sqrt( 0 + 7,018*(-26,84+207,62214)<sup>2</sup> + (-11,63*(9,151+207,62214)<sup>2</sup> )+ ((21,34+207,62214)<sup>2</sup>*-17,1) + ((25,62+207,62214)<sup>2</sup>*-14,77) ) / 5 = 284,049127522i</p>
</div>
<p>Where:</p>
<ul>
<li>N is the total number of significant taps.</li>
<li><span aria-hidden="true">Pi​</span> is the relative received power of the <span aria-hidden="true">i</span>-th tap.</li>
<li><span aria-hidden="true">τi​</span> is the time delay of the i<span aria-hidden="true">i</span>-th tap.</li>
<li><span aria-hidden="true">τˉ</span> is the mean delay</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Assuming the constant part of the channel is the strongest ray and all other rays are the random part compute the Rice Factor.</p>
<blockquote id="Lab82B_c0_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>K = P<sub>Constant</sub>/Σ(P<sub>random</sub>) =&gt; K = -26,84/ (-11,63 - 17,1 -14,77) = 0,617011494</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.3 Set 3</h6>
<p><strong>A.</strong> Set the Number of interaction equal to 8 from the slider button. Click on the Pick a R<sub>x</sub> line button and draw a horizontal line to the right of the T<sub>x</sub>, by clicking once at the beginning and click once on the end of the line. Click on the PDP at a line button. Comment on the Rice factor and RMS delay spread obtained by the simulations.</p>
<blockquote id="Lab83A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_4.png" alt="" width="741" height="290"></p>
<p>The rice factor starts strong but after some distance it gets 0. The RMS delay has flactuations reaching the highest point at 27m .</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now click again on the Pick a R<sub>x</sub> line and draw the line presented in the figure Click on the PDP at a line button Comment on the expected nature of the channel along the two lines.</p>
<blockquote id="Lab83B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>which figure?</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.4 Set 4</h6>
<p>We now switch to Scenario 2.</p>
<p><strong>A.</strong> Click on T<sub>x</sub> (AP) 5 of the network. Then click the Generic Network button of the GUI. Use ONLY the Received Power figure and click on the data cursor option of the Figure. Place the cursor on X=39 and Y=30 and write down the received field.</p>
<blockquote id="Lab84A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_5.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now deselect the T<sub>x5</sub> and select T<sub>x20</sub>. Then click the Generic Network button of the GUI. Use ONLY the Received Power figure and click on the data cursor option of the&nbsp;Figure. Place the cursor on X=39 and Y=30 and write down the received field.</p>
<blockquote id="Lab84B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_6.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Compute the C/I ratio assuming T<sub>x5</sub> is the carrier and T<sub>x20</sub> is the interferer.</p>
<blockquote id="Lab84C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>C/I = -73.3317/-76.2743 = 0,961420819</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>D.</strong> Now click on both T<sub>x5</sub> and T<sub>x20</sub> and click the Generic Network button of the GUI. Use ONLY the C/I figure and click on the data cursor option of the Figure. Place the cursor on X=39 and Y=30 and write down the received field. Compare the values.</p>
<blockquote id="Lab84D_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_8.png" alt=""></p>
<p>The value is bigger that what i got from the calculations this could be due to waveguiding effect. Also there is some confusion about in what values the graphs calculate and if i have logarithmic scale.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>E.</strong> Now select T<sub>x49</sub> and compute the new C/I assuming T<sub>x5</sub> is the carrier and T<sub>x20</sub> and T<sub>x49</sub> are interferers. Compare your result to the obtained by the simulation value.</p>
<blockquote id="Lab84E_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_9.png" alt=""></p>
<p>C/I = -73.3317/(-76.2743+-83.3255) = 0.45947238</p>
<p><img src="userfiles/images/lab6_1_1_10.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>F.</strong> Now click on the <span style="font-family: 'courier new', courier, monospace;">Setup Tx</span> button and set the gain of T<sub>x5</sub> from 2 dBi to 10dBi. Perform the C/I computation and simulation for the network T<sub>x5</sub>, T<sub>x20</sub>, T<sub>x49</sub>. Observe the cell shapes. Change the SNIR threshold and observe coverage estimations.</p>
<blockquote id="Lab84F_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_14.png" alt="" width="630" height="422"></p>
<p>C/I = -65.3317/(-76.2743+-83.3255) = 0,409347004</p>
<p><img src="userfiles/images/lab6_1_1_12.png" alt=""></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="userfiles/images/lab6_1_1_13.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.5 Set 5</h6>
<p>In this exercise we will investigate OFDM indoor networks.</p>
<p><strong>A.</strong> Select T<sub>x37</sub>, <sub>25</sub> and <sub>5</sub> to transmit with their default values and gains. Set the number of subcarriers per user equal to 250. Set the collision probability equal to 0 (non overlapping subcarriers-no interference). Keep other values equal to the default ones. Click on the OFDM Network button of the GUI. Observe the results and write down the obtained values presented in the workspace.</p>
<blockquote id="Lab85A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_15.png" alt=""></p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now change the collision probability equal to 0.5. Run again the OFDM Network. Observe the results and write down the obtained values presented in the workspace.</p>
<blockquote id="Lab85B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<ol>
<li><img src="userfiles/images/lab6_1_1_16.png" alt=""></li>
</ol>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>C.</strong> Compare the values for collision probability equal to 0 and 0.5 and comment on the need for resource allocation schemes on OFDM systems.</p>
<blockquote id="Lab85C_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p>I can observe that with 0 collision probability we can use a 64QAM system and have grear coverage, but when the collision probability increases the modulation to lower bandwidth ones</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.6 Set 6</h6>
<p>In this exercise we will introduce basic network planning strategies basic on static system level simulations.</p>
<p>Set the minimum number of users at the Monte Carlo equal to 2 and maximum number of users equal to 10. Set the Runs equal to 1000.</p>
<p>You want to deploy a femtocell OFDM network in the indoor environment. You are required to obtain a coverage percentage of at least 90% of the possible indoor users. You need to investigate network topologies with different positions and power levels of AP (keeping the gain equal to 2) assuming a 10MHz system BW, 1000 subcarriers, 250 subcarriers per user and collision probability equal to 0.3.</p>
<p><strong>A.</strong> Provide a case study of two network topologies namely NT<sub>1</sub> and NT<sub>2</sub>. NT<sub>1</sub> will target to coverage with the minimum number of AP NT<sub>2</sub> will target to coverage with the minimum transmit power by the user terminals.</p>
<p><em>(Tip: In order to observe if the coverage is greater than 90% of your network topology first click on the OFDM Network button of the GUI. If the coverage (presented at the workspace) is greater than 90% you can proceed to the simplified Monte Carlo analysis by clicking on the Monte Carlo button of the GUI. Compare your networks in terms of SINR effective, Tx power of mobile users, percentage of QPSK, 16 QAM, 64 QAM. Comment on your results.</em> <span style="color: #993300;"><em>This is a big exercise and gets a large part of the total lab grade!!</em></span>)</p>
<blockquote id="Lab86A_c2_w2" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><strong>NT1 network topology:</strong></p>
<p>Using only 1 Tx is impossible to acheive an over 90% coverage. By using 2 transmitters at the edges of the corridors we can achieve an over 90% coverage either for example by enabling 37 and 16 or (14 or 8) and 39. Its also important the transmitters to be in a diagonal to prevent interferances to achieve an over 90% coverage .</p>
<p>Network of 8 and 39:</p>
<p><img src="userfiles/images/lab6_1_1_17.png" alt=""><img src="userfiles/images/lab6_1_1_18.png" alt=""></p>
<p>&nbsp;</p>
<p>Network of 37 and 16:</p>
<p><img src="userfiles/images/lab6_1_1_20.png" alt=""></p>
<p><img src="userfiles/images/lab6_1_1_19.png" alt=""></p>
<p>&nbsp;</p>
<p>As i can observe for a network of 8 and 39 which is a bit better in OFDM than 37 and 16 and the 37 and 16 has a bit better coverage but both are good enough and beyond 90% with the minimun possible APs.</p>
<p>&nbsp;</p>
<p><strong>NT2 network topology:</strong></p>
<p>Now we need the minimun number of transmit power for a coverage greater than 90%. For the previous networks i observe the power consuption and i can see that the 8 and 39 network is better in terms of cosumption and still well beyond 90%.<img src="userfiles/images/lab6_1_1_21.png" alt=""></p>
<p>the 8 and 39 is on the left, the other one on the right.</p>
<p>By experimenting with an increasing number of APs starting from the number of 3 i observe that at 3 APs i dont get better in terms of power just i see higher average values with an overall highest smaller value but the summation of them is probably higher. Further increasing the network with 5 APs i get what seems to be a better transmit power</p>
<p>Topology with 5 APs:</p>
<p><img src="userfiles/images/lab6_1_1_22.png" alt=""></p>
<p>By taking even bigger topologies and avoiding corridors i get what seems to be an even better result in power</p>
<p><img src="userfiles/images/lab6_1_1_23.png" alt=""></p>
<p>&nbsp;</p>
<p>I believe that the network with the a number of APs in the inner area which is encloased will be the one with the least transmit power as i can observe below.</p>
<p><img src="userfiles/images/lab6_1_1_24.png" alt=""></p>
<p>Lastly i tried to open everything which resulted in the results below which i believe are a bit worse that the previous results shoown above:</p>
<p><img src="userfiles/images/lab6_1_1_25.png" alt=""></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<h6>6.2.7 Set 7</h6>
<p>In this exercise the user get introduced to CDMA characteristics.</p>
<p><strong>A.</strong> Set the chip rate equal to 3.84MHz. Set the bit rate equal to 250Kbps. Set the orthogonality factor equal to 0.6 and the Eb/I threshold equal to 6dB. Set the User T<sub>x</sub> power (power of AP associated to user) equal to -16dBW. Select T<sub>x</sub>&nbsp; AP with numbers <sub>2, 5, 7, 25, 28, 30, 32</sub>. Click on the CDMA Network button of the GUI. Now change the bit rate to 64Kbps and the User T<sub>x</sub> power (power of AP associated to user) equal to -21dBW. Click on the CDMA Network button of the GUI. Now change the bit rate to 250Kbps and the User T<sub>x</sub> power (power of AP associated to user) equal to -21dBW. Click on the CDMA Network button of the GUI. What do you observe? Comment on the effect of bitrate to the power required the T<sub>x</sub> to assign to the user.</p>
<blockquote id="Lab87A_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_26.png" alt=""></p>
<p>Each case is presented as it was told from left to right.</p>
<p>In the CDMA i dont observe many differances but generally:</p>
<ul>
<li>
<p><strong>Effect of Bitrate on Tx Power:</strong></p>
<ul>
<li>Generally, lower bit rates allow for more efficient use of available power resources.</li>
<li>In the second step (64 Kbps), with a lower bit rate and decreased user transmit power, i might observe a reduction in the required Tx power for each user.</li>
<li>Conversely, in the third step (250 Kbps) with a higher bit rate and the same user transmit power, i should observe an increase in required Tx power for each user.</li>
</ul>
</li>
<li>
<p><strong>Impact on Power Assignment:</strong></p>
<ul>
<li>Lowering the bit rate allows for a more spread-out and efficient use of the available power, potentially enabling more users to be served within the given constraints.</li>
</ul>
</li>
</ul>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
<p><strong>B.</strong> Now change the bit rate to 64Kbps and the User T<sub>x</sub> power (power of AP associated to user) equal to -21dBW. Now change the orhogonality factor from 0.6 to 0.3. Click on the CDMA network button. Finally change the orhogonality factor to 1 and click on the CDMA Network button of the GUI. Comment on the results.</p>
<blockquote id="Lab87B_c1_w1" class="mceEditable">
<p><span class="mceNonEditable" style="font-size: 12px; color: #ff6600;">=========================</span></p>
<p><span style="font-size: 12px; color: #ff6600;">Your answer here. Feel free to add images. </span></p>
<p><img src="userfiles/images/lab6_1_1_27.png" alt=""></p>
<p>I cant observe many differences.</p>
<p><span style="font-size: 12px;"><strong><span style="background-color: #ffff99; color: #ff6600;">Do NOT erase the blockquote (light blue area) surrounding your answer!</span></strong></span></p>
</blockquote>
</div>
